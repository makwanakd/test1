<?php
namespace Icecube\Businesses\Block\Frontend;

class Index extends \Magento\Framework\View\Element\Template
{
    protected $_storeManager;
    protected $_urlInterface;
 	protected $_modelIndexFactory;
 	protected $currentCustomer;
 	protected $objectmanager;
 	protected $_modelFollowFactory;
 	protected $_modelReviewsFactory;
 	protected $_modelCommentsFactory;
 	
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,        
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\UrlInterface $urlInterface,
        \Icecube\Businesses\Model\ResourceModel\Index\CollectionFactory $modelIndexFactory,
        \Magento\Customer\Helper\Session\CurrentCustomer $currentCustomer,
        \Magento\Framework\ObjectManagerInterface $objectmanager,   
        \Icecube\Businesses\Model\ResourceModel\Follow\CollectionFactory $modelFollowFactory,
        \Icecube\Businesses\Model\ResourceModel\Reviews\CollectionFactory $modelReviewsFactory,
        \Icecube\Businesses\Model\ResourceModel\Comments\CollectionFactory $modelCommentsFactory,
        array $data = []
    )
    {
    	 $this->_modelIndexFactory = $modelIndexFactory;        
        $this->_storeManager = $storeManager;
        $this->_urlInterface = $urlInterface;
        $this->currentCustomer = $currentCustomer;  
        $this->_objectManager = $objectmanager;
        $this->_modelFollowFactory = $modelFollowFactory; 
        $this->_modelReviewsFactory = $modelReviewsFactory; 
        $this->_modelCommentsFactory = $modelCommentsFactory; 
        parent::__construct($context, $data);
    }
    
    public function _prepareLayout()
    {
        return parent::_prepareLayout();
    }
    
    /**
     * Prining URLs using StoreManagerInterface
     */
    public function getMediaUrl()
    {
		return $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
	}
    public function getStoreUrl()
    {
		return $this->_storeManager->getStore()->getBaseUrl();
	}
	public function getCollection($page_id)
	{
		$indexModel = $this->_objectManager->create('Icecube\Businesses\Model\Index');
		$item = $indexModel->load($page_id,'page_id');
        return $item;
	}
	public function getPageid($id)
	{
		$indexModel = $this->_objectManager->create('Icecube\Businesses\Model\Index');
		$item = $indexModel->load($id,'business_id');
        return $item;
	}
	public function getCollectionFactory()
	{
		$indexModel = $this->_modelIndexFactory->create();
		$item = $indexModel->load();
        return $item->getData();
	}
	public function getBusiness(){
		$id = $this->getRequest()->getParam('id');
        if ($id) {
			$model = $this->_objectManager->create('Icecube\Businesses\Model\Businesses');
			$model->load($id);
			return $model;
		}
		return false;
    }
    public function getCustomerId(){
          return $this->currentCustomer->getCustomerId();
    }
    public function getBusinessWebsite($customerid)
	{	
		$customer = $this->_objectManager->create('Magento\Customer\Model\Customer');
		$customerData = $customer->load($customerid);
		foreach ($customerData->getAddresses() as $address)
		{
		    $data = $address->toArray();
		    return $data['website_name'];
		    break;
		}
	} 
	public function getBusinessCategory($customerid)
	{	
		$customer = $this->_objectManager->create('Magento\Customer\Model\Customer');
		$customerData = $customer->load($customerid);
		$category = $this->_objectManager->create('\Icecube\Extrafields\Model\Category\Types')->getAllOptions();
		foreach($category as $c):
			if($c['value'] == $customerData->getBusinessCategory()):
				return $c['label'];
				break;
			endif;
		endforeach;
	}
	public function remove_http($url) {
	   $disallowed = array('http://', 'https://');
	   foreach($disallowed as $d) {
	      if(strpos($url, $d) === 0) {
	         return str_replace($d, '', $url);
	      }
	   }
	   return $url;
	}
	public function getTotalFollows($business_id)
	{
		$followModel = $this->_modelFollowFactory->create();
		$item = $followModel->addFieldToFilter('business_id',$business_id)->load();
        return count($item->getData());
	} 
	public function getCheckFollow($customer_id)
	{
		if($customer_id != null || $customer_id != ''):
			$checkFollow = $this->_objectManager->create('Icecube\Businesses\Model\Follow');
			$item = $checkFollow->load($customer_id,'customer_id');
	        if(count($item) == 0):
	        	return count($item);
	        else:
	        	return $item->getBusinessfollowId();
	        endif;
	    endif;
	}
	public function getReviews($business_id)
	{
		$reviewModel = $this->_modelReviewsFactory->create();
		$items = $reviewModel->addFieldToFilter('business_id',$business_id)->setOrder('businessreview_id','DESC')->load();
        return $items;
	} 
	public function getComments($reviewId)
	{
		$commentModel = $this->_modelCommentsFactory->create();
		$items = $commentModel->addFieldToFilter('review_id',$reviewId)->load();
        return $items;
	} 
	public function getCustomerDetails($customerid)
	{	
		$customer = $this->_objectManager->create('Magento\Customer\Model\Customer');
		$customerData = $customer->load($customerid);
		return $customerData;
	} 
}