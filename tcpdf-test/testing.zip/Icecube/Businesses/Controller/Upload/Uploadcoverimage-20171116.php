<?php
namespace Icecube\Businesses\Controller\Upload;

use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\App\Action\Action;
use Magento\Framework\Filesystem;
use Magento\Framework\UrlInterface;

class Uploadcoverimage extends Action
{
	protected $_fileUploaderFactory;
 	
 	protected $subDir = 'business/cover/';
 	
 	protected $profileDir = 'business/profile/';
 	
 	protected $fileSystem;
 	
 	protected $resultJsonFactory;
 	
 	protected $urlBuilder;
 	
 	protected $objectmanager;
 	
	public function __construct(
	    \Magento\MediaStorage\Model\File\UploaderFactory $fileUploaderFactory,
	    \Magento\Framework\App\Action\Context $context,
	    \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
	    \Magento\Framework\ObjectManagerInterface $objectmanager,
	    Filesystem $fileSystem,
	    UrlInterface $urlBuilder
	) {
		$this->_urlBuilder = $urlBuilder;
	 	$this->_filesystem = $fileSystem;
	    $this->_fileUploaderFactory = $fileUploaderFactory;
	    $this->resultJsonFactory = $resultJsonFactory;
	    $this->_objectManager = $objectmanager;
	    parent::__construct($context);
	}
	 
	public function execute() {
		$request = $this->getRequest();
		$id = (int)$request->getParam('id');
	    $img = $request->getParam('image');
        if($img == 'cover'):
	        $uploader = $this->_fileUploaderFactory->create(['fileId' => 'cover-image']);
		    $uploader->setAllowedExtensions(['jpg', 'jpeg', 'gif', 'png']);
		    $uploader->setAllowRenameFiles(true);
	        $uploader->setFilesDispersion(true);
	        $uploader->setAllowCreateFolders(true);
		    $path = $this->_filesystem->getDirectoryRead(DirectoryList::MEDIA)->getAbsolutePath($this->subDir.'images/');
		    $filename = $uploader->save($path)['file'];
		    $data['image'] = $this->getMediaUrl($this->subDir).$filename;
		    $save = $this->getSaveUrl($this->subDir).$filename;
		    $this->setSave($id,$save);
	    else:
		    $uploader = $this->_fileUploaderFactory->create(['fileId' => 'profile-img']);
		    $uploader->setAllowedExtensions(['jpg', 'jpeg', 'gif', 'png']);
		    $uploader->setAllowRenameFiles(true);
	        $uploader->setFilesDispersion(true);
	        $uploader->setAllowCreateFolders(true);
		    $path = $this->_filesystem->getDirectoryRead(DirectoryList::MEDIA)->getAbsolutePath($this->profileDir.'images/');
		    $filename = $uploader->save($path)['file'];
		    
		    $save = $this->getSaveUrl($this->profileDir).$filename;
		    if($customerid = $request->getParam('customerid')):
		    	$data['image'] = $this->getMediaUrl($this->profileDir).$filename;
	    		$this->setSaveProfile($id,$save,$customerid);
	    	else:
	    		$data['error'] = 'Can\'t Upload Image';
	    	endif;
	    endif;
	    $result = $this->resultJsonFactory->create()->setData($data);
	 	return $result;
	}
	public function getMediaUrl($dir)
    {
        return $this->_urlBuilder->getBaseUrl(['_type' => UrlInterface::URL_TYPE_MEDIA]).$dir.'images';
    }
    public function getSaveUrl($dir)
    {
		return $dir.'images';
	}
	private function setSave($id,$save)
	{
		$template = $this->_objectManager->create('Icecube\Businesses\Model\Index');
		$template->load($id,'business_id');
		$template->setData('image',
	    	$save
        );
        $template->save();
	}
	private function setSaveProfile($id,$save,$customerid)
	{	
		/*$customer = $this->_objectManager->create('Magento\Customer\Model\Customer');
		$customerData = $customer->load($customerid);
		$customerData->setProfileImage($save);
		$customerData->save();*/
		$customerFactory = $this->_objectManager->create('Magento\Customer\Model\CustomerFactory');
		$customer = $this->_objectManager->create('Magento\Customer\Model\Customer');
		$customerData = $this->_objectManager->create('Magento\Customer\Model\Data\Customer');
		$customerResourceFactory = $this->_objectManager->create('Magento\Customer\Model\ResourceModel\CustomerFactory');
		$customer = $customerFactory->create();
		$customerData = $customer->getDataModel();
		$customerData->setId($customerid);
		$customerData->setCustomAttribute('profile_image', $save);
		$customer->updateData($customerData);
		$customerResource = $customerResourceFactory->create();
		if ($save != "") {
		    $customerResource->saveAttribute($customer, 'profile_image');
		}
	}
}