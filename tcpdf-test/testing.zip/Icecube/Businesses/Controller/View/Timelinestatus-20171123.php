<?php
namespace Icecube\Businesses\Controller\View;

use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\App\Action\Action;
use Magento\Framework\Filesystem;
use Magento\Framework\UrlInterface;

class Timelinestatus extends Action
{
	protected $_fileUploaderFactory;
 	
 	protected $subDir = 'business/status/';
 	
 	protected $fileSystem;
 	
 	protected $resultJsonFactory;
 	
 	protected $urlBuilder;
 	
 	protected $objectmanager;
 	
 	protected $_dateFactory;
	
	public function __construct(
	    \Magento\MediaStorage\Model\File\UploaderFactory $fileUploaderFactory,
	    \Magento\Framework\App\Action\Context $context,
	    \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
	    \Magento\Framework\ObjectManagerInterface $objectmanager,
	    Filesystem $fileSystem,
	    UrlInterface $urlBuilder,
	    \Magento\Framework\Stdlib\DateTime\DateTimeFactory $dateFactory
	) {
		$this->_urlBuilder = $urlBuilder;
	 	$this->_filesystem = $fileSystem;
	    $this->_fileUploaderFactory = $fileUploaderFactory;
	    $this->resultJsonFactory = $resultJsonFactory;
	    $this->_objectManager = $objectmanager;
	    $this->_dateFactory = $dateFactory;
	    parent::__construct($context);
	}
	 
	public function execute() {
		$request = $this->getRequest();
		$id = (int)$request->getParam('id');
		$type = (int)$request->getParam('type');
		$text = $request->getParam('text');
		$img = $request->getParam('imageuploaded');
		$businessUserId = $request->getParam('business_user');
		if($img != 0):
	        $uploader = $this->_fileUploaderFactory->create(['fileId' => 'status-image']);
		    $uploader->setAllowedExtensions(['jpg', 'jpeg', 'gif', 'png']);
		    $uploader->setAllowRenameFiles(true);
	        $uploader->setFilesDispersion(true);
	        $uploader->setAllowCreateFolders(true);
		    $path = $this->_filesystem->getDirectoryRead(DirectoryList::MEDIA)->getAbsolutePath($this->subDir.'images/');
		    $filename = $uploader->save($path)['file'];
		    $data['image'] = $this->getMediaUrl($this->subDir).$filename;
		    $save = $this->getSaveUrl($this->subDir).$filename;
		    $data['date'] = $this->setSave($id,$save,$text,$type,$businessUserId);
		    $result = $this->resultJsonFactory->create()->setData($data);
		 	return $result;
		 else:
		 	$this->setSave($id,'',$text,$type,$businessUserId);
		 	$data['image'] = "Image Not Uploaded";
		    $result = $this->resultJsonFactory->create()->setData($data);
		 	return $result;
		 endif;
	}
	public function getMediaUrl($dir)
    {
        return $this->_urlBuilder->getBaseUrl(['_type' => UrlInterface::URL_TYPE_MEDIA]).$dir.'images';
    }
    public function getSaveUrl($dir)
    {
		return $dir.'images';
	}
	private function setSave($id,$save,$text,$type,$businessUserId)
	{
		$template = $this->_objectManager->create('Icecube\Businesses\Model\Timelinestatus');
		$today = date('Y-m-d H:i:s');
		$template->setData('text',
	    	$text
	    )->setData('date_time',
	    	$today
	    )->setData('image',
	    	$save
	    )->setData('type',
	    	$type
	    )->setData('business_id',
	    	$id
        );
        $template->save();
        
        
        $date = $this->_dateFactory->create()->gmtDate();			
		$review = $this->_objectManager->create('Icecube\Businesses\Model\Reviews');
		$review->setData('business_id',
	    	$id
	    )->setData('status',
	    	'1'
        )->setData('datetime',
	    	$date
        )->setData('status_id',
	    	$template->getId()
        )
		->setData('customer_id',
	    	$businessUserId
        );
        $review->save();
        
        return $today;
	}
}