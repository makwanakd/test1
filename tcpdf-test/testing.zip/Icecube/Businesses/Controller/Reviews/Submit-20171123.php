<?php
namespace Icecube\Businesses\Controller\Reviews;

use Magento\Framework\App\Action\Action;
use Magento\Framework\Controller\ResultFactory;

class Submit extends Action
{
	protected $resultRedirect;
	protected $_dateFactory;
	public function __construct(
	    \Magento\Framework\App\Action\Context $context,
	    \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
	    \Magento\Framework\ObjectManagerInterface $objectmanager,
	    ResultFactory $result,
	    \Magento\Framework\Stdlib\DateTime\DateTimeFactory $dateFactory
	) {
	    $this->resultJsonFactory = $resultJsonFactory;
	    $this->_objectManager = $objectmanager;
	    parent::__construct($context);
	    $this->_dateFactory = $dateFactory;
	    $this->resultRedirect = $result;
	}
		public function execute(){
			$request = $this->getRequest();
			$type = $request->getParam('rating');
			/*var_dump($request->getParam('rating'));
			var_dump($request->getParam('txtreview'));
			var_dump($request->getParam('rcustomerid'));
			var_dump($request->getParam('rbusinessid'));
			var_dump($request->getParam('rpageid'));*/
			
			$request = $this->getRequest();
			 $page_id = (int)$request->getParam('rpageid');
			 $business_id = (int)$request->getParam('rbusinessid');
			 $customer_id = (int)$request->getParam('rcustomerid');
			 $rrating = (int)$request->getParam('rating');
			 $rreview = $request->getParam('txtreview');
			 $status = 1;
			 $date = $this->_dateFactory->create()->gmtDate();
			
			$review = $this->_objectManager->create('Icecube\Businesses\Model\Reviews');
			$review->setData('page_id',
		            $page_id
		    )->setData('business_id',
		    	$business_id
		    )->setData('customer_id',
		    	$customer_id
		    )->setData('review',
		    	$rreview
		    )->setData('rating',
		    	$rrating
		    )->setData('status',
		    	$status
	        )->setData('datetime',
		    	$date
	        );

	        $review->save();
	        $this->messageManager->addSuccess('Review submitted Successfully');
	       	$resultRedirect = $this->resultRedirect->create(ResultFactory::TYPE_REDIRECT);
		    $resultRedirect->setUrl($this->_redirect->getRefererUrl());
		    return $resultRedirect;

	        /*$data['success'] = true;
	        $result = $this->resultJsonFactory->create()->setData($data);		 	*/
	}	
}