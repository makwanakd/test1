<?php
namespace Icecube\Businesses\Controller\Reviews;

use Magento\Framework\App\Action\Action;
use Magento\Framework\Controller\ResultFactory;

class Submitcomment extends Action
{
	protected $resultRedirect;
	protected $_dateFactory;
	public function __construct(
	    \Magento\Framework\App\Action\Context $context,
	    \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
	    \Magento\Framework\ObjectManagerInterface $objectmanager,
	    ResultFactory $result,
	    \Magento\Framework\Stdlib\DateTime\DateTimeFactory $dateFactory
	) {
	    $this->resultJsonFactory = $resultJsonFactory;
	    $this->_objectManager = $objectmanager;
	    parent::__construct($context);
	    $this->_dateFactory = $dateFactory;
	    $this->resultRedirect = $result;
	}
		public function execute(){
			$request = $this->getRequest();
			
			$request = $this->getRequest();
			 $page_id = (int)$request->getParam('cpageid');
			 $business_id = (int)$request->getParam('cbusinessid');
			 $customer_id = (int)$request->getParam('ccustomerid');
			 $ccomment = $request->getParam('ccomment');
			 $creviewid = $request->getParam('creviewid');
			 $status = 1;
			 $date = $this->_dateFactory->create()->gmtDate();
			
			$comment = $this->_objectManager->create('Icecube\Businesses\Model\Comments');
			$comment->setData('page_id',
		            $page_id
		    )->setData('business_id',
		    	$business_id
		    )->setData('review_id',
		    	$creviewid
		    )->setData('customer_id',
		    	$customer_id
		    )->setData('comment',
		    	$ccomment
		    )->setData('status',
		    	$status
	        )->setData('datetime',
		    	$date
	        );

	        $comment->save();
	        $this->messageManager->addSuccess('Comment submitted Successfully');
	       	$resultRedirect = $this->resultRedirect->create(ResultFactory::TYPE_REDIRECT);
		    $resultRedirect->setUrl($this->_redirect->getRefererUrl());
		    return $resultRedirect;

	        /*$data['success'] = true;
	        $result = $this->resultJsonFactory->create()->setData($data);		 	*/
	}	
}