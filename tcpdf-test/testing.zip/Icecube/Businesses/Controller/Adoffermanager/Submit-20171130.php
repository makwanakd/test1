<?php
namespace Icecube\Businesses\Controller\Adoffermanager;

use Magento\Framework\App\Action\Action;
use Magento\Framework\Controller\ResultFactory;
use \Magento\Framework\Mail\Template\TransportBuilder;
use \Magento\Framework\Translate\Inline\StateInterface;
use \Magento\Store\Model\StoreManagerInterface;

class Submit extends Action
{
	protected $resultRedirect;
	protected $_dateFactory;
	protected $inlineTranslation;
    
    protected $transportBuilder;
	
	protected $storeManager;
	
	protected $_scopeConfig;
	
	protected $_modelFollowFactory;
 	protected $_modelReviewsFactory;
 	protected $_modelCommentsFactory;
 	protected $_modelAdoffersFactory;
	public function __construct(
	    \Magento\Framework\App\Action\Context $context,
	    \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
	    \Magento\Framework\ObjectManagerInterface $objectmanager,
	    ResultFactory $result,
	    \Magento\Framework\Stdlib\DateTime\DateTimeFactory $dateFactory,
	    StateInterface $inlineTranslation,
    	TransportBuilder $transportBuilder,
    	StoreManagerInterface $storeManager,
    	\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
    	\Icecube\Businesses\Model\ResourceModel\Follow\CollectionFactory $modelFollowFactory,
        \Icecube\Businesses\Model\ResourceModel\Reviews\CollectionFactory $modelReviewsFactory,
        \Icecube\Businesses\Model\ResourceModel\Comments\CollectionFactory $modelCommentsFactory,
        \Icecube\Businesses\Model\ResourceModel\Adoffers\CollectionFactory $modelAdoffersFactory
	) {
	    $this->resultJsonFactory = $resultJsonFactory;
	    $this->_objectManager = $objectmanager;
	    parent::__construct($context);
	    $this->_dateFactory = $dateFactory;
	    $this->resultRedirect = $result;
	    
	    $this->inlineTranslation = $inlineTranslation;
        $this->_transportBuilder = $transportBuilder;
        $this->storeManager = $storeManager;
	    $this->_scopeConfig = $scopeConfig;
	    $this->_modelFollowFactory = $modelFollowFactory; 
        $this->_modelReviewsFactory = $modelReviewsFactory; 
        $this->_modelCommentsFactory = $modelCommentsFactory;
        $this->_modelAdoffersFactory = $modelAdoffersFactory;
	    
	}
		public function execute(){
			$request = $this->getRequest();
			/*$type = $request->getParam('rating');
			$request = $this->getRequest();*/
			$page_id = '2';
			/*$business_id = (int)$request->getParam('rbusinessid');
			$customer_id = (int)$request->getParam('rcustomerid');
			$rrating = (int)$request->getParam('rating');
			$rreview = $request->getParam('txtreview');
			$status = 1;
			$date = $this->_dateFactory->create()->gmtDate();*/
			
			$adoffers = $this->_objectManager->create('Icecube\Businesses\Model\Adoffers');
			$adoffers->setData('page_id',
		            $page_id
		    )->setData('business_id',
		    	$page_id
		    )->setData('businessuser_id',
		    	$page_id
		    )->setData('logo',
		    	$page_id
		    )->setData('targeting_campaign',
		    	$page_id
		    )->setData('campaign_title',
		    	$page_id
	        )->setData('allocated_inventory',
		    	$page_id
	        )->setData('business_location',
		    	$page_id
	        )->setData('target_market',
		    	$page_id
	        )->setData('adoffer_headline',
		    	$page_id
	        )->setData('offer_type',
		    	$page_id
	        )->setData('promo_code',
		    	$page_id
	        )->setData('expiration_date',
		    	$page_id
	        )->setData('adoffer_description',
		    	$page_id
	        )->setData('how_to_redeem',
		    	$page_id
	        )->setData('terms_conditions',
		    	$page_id
	        )->setData('priorities',
		    	$page_id
	        );

	        $adoffers->save();
	        
	        $this->messageManager->addSuccess('Offers has been saved successfully');
	       	$resultRedirect = $this->resultRedirect->create(ResultFactory::TYPE_REDIRECT);
		    $resultRedirect->setUrl($this->_redirect->getRefererUrl());
		    return $resultRedirect;
	}	
}