<?php
/**
 * Icecube Business Extension 
 * 
 * Icecube_Business
 * 
 * PHP version 5.x
 *
 * @category  Save
 * @preference   Icecube_Business
 * @author    Icecube Digital <support@icecubedigital.com>
 * @copyright 2016 Icecube Digital
 * @license   http://www.php.net/license/3_01.txt  PHP License 3.01
 * @link      http://www.icecubedigital.com
 */
namespace Icecube\Business\Controller\Adminhtml\Preferences;

use Magento\Framework\App\TemplateTypesInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Controller\ResultFactory;

/**
 * Icecube_Business
 *
 * @category  Save
 * @preference   Icecube_Business
 * @author    Icecube Digital <support@icecubedigital.com>
 * @copyright 2016 Icecube Digital
 * @license   http://www.php.net/license/3_01.txt  PHP License 3.01
 * @link      http://www.icecubedigital.com
 */
class Save extends \Icecube\Business\Controller\Adminhtml\Preferences
{
	public function __construct(
        \Magento\Backend\App\Action\Context $context,        
        \Magento\Catalog\Model\ProductRepository $productRepository,
        array $data = []
    )
    {
        $this->_productRepository = $productRepository;
        parent::__construct($context);
    }
    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        $request = $this->getRequest();
        if (!$request->isPost()) {
            $this->getResponse()->setRedirect($this->getUrl('*/preferences'));
        }
        $template = $this->_objectManager->create('Icecube\Business\Model\Preferences');
        
        $id = (int)$request->getParam('id');
        if ($id) {
            $template->load($id);
        }
		if($id) {
			$data = $request->getParams();
			$template->setData('preference_title',
					 $data['preference_title']
				)->setData('status',
            		$data['status']
				);
			$template->save();
            $this->messageManager->addSuccess(__('The Preference has been Updated Successfully.'));
            $this->_getSession()->setFormData(false);
			return $resultRedirect->setPath('*/*/');
		} else {
		try {
				$data = $request->getParams();
				$template->setData('preference_title',
						 $data['preference_title']
					)->setData('status',
	            		$data['status']
					);
				$template->save();
				$this->messageManager->addSuccess(__('The Preference has been saved.'));
				$this->_getSession()->setFormData(false);
			} catch (LocalizedException $e) {
				$this->messageManager->addError(nl2br($e->getMessage()));
				$this->_getSession()->setData('business_preference_form_data', $this->getRequest()->getParams());
				return $resultRedirect->setPath('*/*/edit', ['id' => $template->getBusinesspreferenceId(), '_current' => true]);
			} catch (\Exception $e) {
				 $this->messageManager->addError(nl2br($e->getMessage()));
				$this->messageManager->addException($e, __('Something went wrong while saving this preference.'));
				$this->_getSession()->setData('business_preference_form_data', $this->getRequest()->getParams());
				return $resultRedirect->setPath('*/*/edit', ['id' => $template->getBusinesspreferenceId(), '_current' => true]);
			}
		} 
        return $resultRedirect->setPath('*/*/');
    }
}