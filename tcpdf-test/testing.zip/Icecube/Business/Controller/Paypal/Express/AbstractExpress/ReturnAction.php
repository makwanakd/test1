<?php


namespace Icecube\Business\Controller\Paypal\Express\AbstractExpress;

use Magento\Framework\Controller\ResultFactory;

class ReturnAction extends \Magento\Paypal\Controller\Express\ReturnAction
{
    /**
     * Return from PayPal and dispatch customer to order review page
     *
     * @return void|\Magento\Framework\Controller\Result\Redirect
     */
    public function execute()
    {
        /** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);

        if ($this->getRequest()->getParam('retry_authorization') == 'true'
            && is_array($this->_getCheckoutSession()->getPaypalTransactionData())
        ) {
            $this->_forward('placeOrder');
            return;
        }
        try {
            $this->_getCheckoutSession()->unsPaypalTransactionData();
            $this->_initCheckout();
            $this->_checkout->returnFromPaypal($this->_initToken());
            if ($this->_checkout->canSkipOrderReviewStep()) {
                $this->_forward('placeOrder');
            } else {
                if(isset($_SESSION['checkout_from'])){
                    if($_SESSION['checkout_from']=='business-signup'){
                        $this->_redirect('business-signup');
                    }elseif ($_SESSION['checkout_from']=='add-inventry') {
                        $this->_redirect('add-inventory');
                    }else{
                       $this->_redirect('business-signup'); 
                    }
                }
            }
            return;
        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            $this->messageManager->addExceptionMessage(
                $e,
                $e->getMessage()
            );
        } catch (\Exception $e) {
            $this->messageManager->addExceptionMessage(
                $e,
                __('We can\'t process Express Checkout approval.')
            );
        }

        if(isset($_SESSION['checkout_from'])){
            if($_SESSION['checkout_from']=='business-signup'){
                return $resultRedirect->setPath('business-signup');
            }elseif ($_SESSION['checkout_from']=='add-inventry') {
                return $resultRedirect->setPath('add-inventory');
            }else{
               return $resultRedirect->setPath('business-signup');
            }
        }
    }
}
