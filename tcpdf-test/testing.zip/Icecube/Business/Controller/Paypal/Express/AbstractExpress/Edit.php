<?php
/**
 *
 * Copyright © 2013-2017 Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Icecube\Business\Controller\Paypal\Express\AbstractExpress;

class Edit extends \Magento\Paypal\Controller\Express\Edit
{
    /**
     * Dispatch customer back to PayPal for editing payment information
     *
     * @return void
     */
    public function execute()
    {
        try {
            $this->getResponse()->setRedirect($this->_config->getExpressCheckoutEditUrl($this->_initToken()));
        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            $this->messageManager->addExceptionMessage(
                $e,
                $e->getMessage()
            );
            if(isset($_SESSION['checkout_from'])){
                if($_SESSION['checkout_from']=='business-signup'){
                    $this->_redirect('business-signup');
                }elseif ($_SESSION['checkout_from']=='add-inventry') {
                    $this->_redirect('add-inventory');
                }else{
                   $this->_redirect('business-signup'); 
                }
            }
        }
    }
}
