<?php
namespace Icecube\Business\Controller\Frontend;

use Magento\Framework\App\Action\Context;


class Validbusinessname extends \Magento\Framework\App\Action\Action
{
   

    /**
     * @param Context $context
     * @param \Magento\Checkout\Model\Session $checkoutSession
     * @param CustomerCart $cart
     */
    public function __construct(
        Context $context,
        \Magento\Sales\Model\Order\AddressRepository $repositoryAddress
       /* \Magento\Framework\ObjectManagerInterface $objectManager*/
    ) {
        
        $this->repositoryAddress = $repositoryAddress;
        /*$this->_objectManager = $objectManager;*/
        parent::__construct($context);
    }

    public function execute()
    {
      $post = $this->getRequest()->getPostValue();
      if($post){
      if(isset($post['insertedBusinessName'])){
         $businessname = $post['insertedBusinessName'];
          $businessname = str_replace(' ', '-', $businessname); 
      }
      $resource = $this->_objectManager->get('Magento\Framework\App\ResourceConnection');
      $connection = $resource->getConnection();
      $sql = "Select * FROM mgsh_businesses where business_page_url = '$businessname'";
      $result = $connection->fetchAll($sql);   
      if($result){
        echo "match";
      }else{
        echo"not match";
      }
    }
}
}