<?php
namespace Icecube\Business\Controller\Frontend;

use Magento\Framework\App\Action\Context;
use Magento\Catalog\Model\Cart as CustomerCart;
use Magento\Store\Model\StoreManagerInterface;

class Checkoutinventory extends \Magento\Framework\App\Action\Action
{
    protected $checkoutSession;
	protected $storeManager;
    public function __construct(
        Context $context,
        \Magento\Newsletter\Model\Session $checkoutSession,
        StoreManagerInterface $storeManager
    ) {
        $this->checkoutSession = $checkoutSession;
		$this->storeManager = $storeManager;
        parent::__construct($context);
    }

    public function execute()
    {
    	
    	
    	 $_SESSION['checkout_from'] = 'add-inventry'; 
        //$_SESSION['business_data1'] = $businessData;
       // $this->checkoutSession->setBusinessData($businessData);
        
       
        $response = [
            'success' => true,
        ];

        $this->getResponse()->representJson(
            $this->_objectManager->get('Magento\Framework\Json\Helper\Data')->jsonEncode($response)
        );
    }
}