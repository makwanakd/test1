<?php
namespace Icecube\Business\Controller\Frontend;

use Magento\Framework\App\Action\Context;
use Magento\Catalog\Model\Cart as CustomerCart;
use Magento\Store\Model\StoreManagerInterface;

class Signup extends \Magento\Framework\App\Action\Action
{
    protected $checkoutSession;
	protected $storeManager;
    public function __construct(
        Context $context,
        \Magento\Newsletter\Model\Session $checkoutSession,
        StoreManagerInterface $storeManager
    ) {
        $this->checkoutSession = $checkoutSession;
		$this->storeManager = $storeManager;
        parent::__construct($context);
    }

    public function execute()
    {
    	$post = $this->getRequest()->getPostValue();
    	if($post){
    		
    		/*if(isset($post['checkemailexistance'])){
				$checkemailexistance = $post['checkemailexistance'];
				!=valid
			}*/
			
			$firstname = '';
			$lastname = '';
			$businessEmail = '';
			$businessName = '';
			$businessPhonenumber = '';
			$businessCategory = '';
			$businessPassword = '';
			$businessLocationName = '';
			$businessSA1 = '';
			$businessSA2 = '';
			$businessState = '';
			$businessLocationPhonenumber = '';
			$businessCity = '';
			$businessPincode = '';
			$businessWebsite = '';
			$businessLocationName2 = '';
			$businessSA12 = '';
			$businessSA22 = '';
			$businessState2 = '';
			$businessLocationPhonenumber2 = '';
			$businessCity2 = '';
			$businessPincode2 = '';
			$businessWebsite2 = '';
			$businessLocationName3 = '';
			$businessSA13 = '';
			$businessSA23 = '';
			$businessState3 = '';
			$businessLocationPhonenumber3 = '';
			$businessCity3 = '';
			$businessPincode3 = '';
			$businessWebsite3 = '';
			$sameAsShipping = '';
			$subscribeme = '';
			
    		if(isset($post['business-fname'])){
				$firstname = $post['business-fname'];
			}
			if(isset($post['business-lname'])){
				$lastname = $post['business-lname'];
			}
			
			if(isset($post['business-email'])){
				$businessEmail = $post['business-email'];
			}
			if(isset($post['business-name'])){
				$businessName = $post['business-name'];
			}
			if(isset($post['business-phonenumber'])){
				$businessPhonenumber = $post['business-phonenumber'];
			}
			if(isset($post['business-category'])){
				$businessCategory = $post['business-category'];
			}
			if(isset($post['password'])){
				$businessPassword = $post['password'];
			}			
			if(isset($post['business-location-name'])){
				$businessLocationName = $post['business-location-name'];
			}
			if(isset($post['business-street-address-1'])){
				$businessSA1 = $post['business-street-address-1'];
			}
			if(isset($post['business-street-address-2'])){
				$businessSA2 = $post['business-street-address-2'];
				/*if($businessSA2!=''){
					$businessSA1 .= "\n".$businessSA2;
				}*/
			}
			if(isset($post['business-state'])){
				$businessState = $post['business-state'];
			}
			if(isset($post['business-location-phonenumber'])){
				$businessLocationPhonenumber = $post['business-location-phonenumber'];
			}
			if(isset($post['business-city'])){
				$businessCity = $post['business-city'];
			}
			if(isset($post['business-pincode'])){
				$businessPincode = $post['business-pincode'];
			}
			if(isset($post['business-pincode'])){
				$businessPincode = $post['business-pincode'];
			}
			if(isset($post['business-website'])){
				$businessWebsite = $post['business-website'];
			}
			
			
			if(isset($post['business-location-name2'])){
				$businessLocationName2 = $post['business-location-name2'];
			}
			if(isset($post['business-street-address-12'])){
				$businessSA12 = $post['business-street-address-12'];
			}
			if(isset($post['business-street-address-22'])){
				$businessSA22 = $post['business-street-address-22'];
				/*if($businessSA22!=''){
					$businessSA12 .= "\n".$businessSA22;
				}*/
			}
			if(isset($post['business-state2'])){
				$businessState2 = $post['business-state2'];
			}
			if(isset($post['business-location-phonenumber2'])){
				$businessLocationPhonenumber2 = $post['business-location-phonenumber2'];
			}
			if(isset($post['business-city2'])){
				$businessCity2 = $post['business-city2'];
			}
			if(isset($post['business-pincode2'])){
				$businessPincode2 = $post['business-pincode2'];
			}
			if(isset($post['business-website2'])){
				$businessWebsite2 = $post['business-website2'];
			}
			
			
			if(isset($post['business-location-name3'])){
				$businessLocationName3 = $post['business-location-name3'];
			}
			if(isset($post['business-street-address-13'])){
				$businessSA13 = $post['business-street-address-13'];
			}
			if(isset($post['business-street-address-23'])){
				$businessSA23 = $post['business-street-address-23'];
				/*if($businessSA23!=''){
					$businessSA13 .= "\n".$businessSA23;
				}*/
			}
			if(isset($post['business-state3'])){
				$businessState3 = $post['business-state3'];
			}
			if(isset($post['business-location-phonenumber3'])){
				$businessLocationPhonenumber3 = $post['business-location-phonenumber3'];
			}
			if(isset($post['business-city3'])){
				$businessCity3 = $post['business-city3'];
			}
			if(isset($post['business-pincode3'])){
				$businessPincode3 = $post['business-pincode3'];
			}
			if(isset($post['business-website3'])){
				$businessWebsite3 = $post['business-website3'];
			}
			
			if(isset($post['checkbox-1'])){
				$sameAsShipping = $post['checkbox-1'];
			}
			if(isset($post['checkbox-3'])){
				$subscribeme = $post['checkbox-3'];
			}
		}
    	$businessData = array();
    	$basicInfo = array();
        $location1 = array();
        $location2 = array();
        $location3 = array();
        
        $basicInfo['business-fname'] = $firstname;
        $basicInfo['business-lname'] = $lastname;
        $basicInfo['business-email'] = $businessEmail;
        $basicInfo['business-name'] = $businessName;
        $basicInfo['business-phonenumber'] = $businessPhonenumber;
        $basicInfo['business-category'] = $businessCategory;
        $basicInfo['password'] = $businessPassword;
        $basicInfo['same-as-shipping'] = $sameAsShipping;
        $basicInfo['subscribeme'] = $subscribeme;
        
        $location1['business-location-name'] = $businessLocationName;
        $location1['business-street-address-1'] = $businessSA1;
        $location1['business-street-address-2'] = $businessSA2;
        $location1['business-state'] = $businessState;
        $location1['business-location-phonenumber'] = $businessLocationPhonenumber;
        $location1['business-city'] = $businessCity;
        $location1['business-pincode'] = $businessPincode;
        $location1['business-website'] = $businessWebsite;
        
        $location2['business-location-name2'] = $businessLocationName2;
        $location2['business-street-address-12'] = $businessSA12;
        $location2['business-street-address-22'] = $businessSA22;
        $location2['business-state2'] = $businessState2;
        $location2['business-location-phonenumber2'] = $businessLocationPhonenumber2;
        $location2['business-city2'] = $businessCity2;
        $location2['business-pincode2'] = $businessPincode2;
        $location2['business-website2'] = $businessWebsite3;
        
        
        $location3['business-location-name3'] = $businessLocationName3;
        $location3['business-street-address-13'] = $businessSA13;
        $location3['business-street-address-23'] = $businessSA23;
        $location3['business-state3'] = $businessState3;
        $location3['business-location-phonenumber3'] = $businessLocationPhonenumber3;
        $location3['business-city3'] = $businessCity3;
        $location3['business-pincode3'] = $businessPincode3;
        $location3['business-website3'] = $businessWebsite3;
        
        
        $businessData['basicinfo'] = $basicInfo;
        $businessData['location1'] = $location1;
        $businessData['location2'] = $location2;
        $businessData['location3'] = $location3;
        
        

        
        
        
        $_SESSION['business_data1'] = $businessData;
        $_SESSION['checkout_from'] = 'business-signup'; 

        $this->checkoutSession->setBusinessData($businessData);
        /*var_dump($this->checkoutSession->getBusinessData());
        die;*/
        /*$businessDataFetch = $this->checkoutSession->getBusinessData(); */
        
		/*$url = \Magento\Framework\App\ObjectManager::getInstance();		 
		$customerFactory = $this->_objectManager->get('\Magento\Customer\Model\CustomerFactory');		 
		$websiteId = $this->storeManager->getWebsite()->getWebsiteId();	 	 
		// Instantiate object (this is the most important part)		 
		$customer = $customerFactory->create();		 
		$customer->setWebsiteId($websiteId);		 
		$customer->setEmail($businessEmail);		 
		$customer->setFirstname($firstname);		 
		$customer->setLastname($lastname);		 
		$customer->setBusinessCategory($businessCategory);
		$customer->setGroupId(4);
		$customer->setBusinessName($businessName);
		$customer->setBusinessPhoneNumberCheckout($businessPhonenumber);
		$customer->setPassword($businessPassword);
		
		//$customer->setCustomAttribute('business_phone_number_checkout', $businessPhonenumber);
		$customer->save();		 

        
        if($businessLocationName!=''){
			$addresss = $this->_objectManager->get('\Magento\Customer\Model\AddressFactory');
			$address = $addresss->create();
			$address->setCustomerId($customer->getId())
			->setFirstname($firstname)
			->setLastname($lastname)
			->setCountryId('US')
			->setPostcode($businessPincode)
			->setCity($businessCity)
			->setTelephone($businessLocationPhonenumber)
			->setStreet($businessSA1)
			->setRegionId($businessState)
			->setLocationName($businessLocationName)
			->setWebsiteName($businessWebsite)
			->setIsDefaultBilling('1')
			->setIsDefaultShipping('1')
			->setSaveInAddressBook('1');
			$address->save();
		}
		if($businessLocationName2!=''){
			$addresss2 = $this->_objectManager->get('\Magento\Customer\Model\AddressFactory');
			$address = $addresss2->create();
			$address->setCustomerId($customer->getId())
			->setFirstname($firstname)
			->setLastname($lastname)
			->setCountryId('US')
			->setPostcode($businessPincode2)
			->setCity($businessCity2)
			->setTelephone($businessLocationPhonenumber2)
			->setStreet($businessSA12)
			->setRegionId($businessState2)
			->setLocationName($businessLocationName2)
			->setWebsiteName($businessWebsite2);
			$address->save();
		}
		if($businessLocationName3!=''){
			$addresss3 = $this->_objectManager->get('\Magento\Customer\Model\AddressFactory');
			$address = $addresss3->create();
			$address->setCustomerId($customer->getId())
			->setFirstname($firstname)
			->setLastname($lastname)
			->setCountryId('US')
			->setPostcode($businessPincode3)
			->setCity($businessCity3)
			->setTelephone($businessLocationPhonenumber3)
			->setStreet($businessSA13)
			->setRegionId($businessState3)
			->setLocationName($businessLocationName3)
			->setWebsiteName($businessWebsite3);
			$address->save();
		}*/
        
        
        
        $response = [
            'success' => true,
        ];

        $this->getResponse()->representJson(
            $this->_objectManager->get('Magento\Framework\Json\Helper\Data')->jsonEncode($response)
        );
    }
}