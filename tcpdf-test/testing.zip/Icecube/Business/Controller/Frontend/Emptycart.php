<?php
namespace Icecube\Business\Controller\Frontend;

use Magento\Framework\App\Action\Context;
use Magento\Checkout\Model\Cart as CustomerCart;

class Emptycart extends \Magento\Framework\App\Action\Action
{
    /**
     * @var \Magento\Checkout\Model\Session
     */
    protected $checkoutSession;

    /**
     * @var \Magento\Checkout\Model\Cart
     */
    protected $cart;

    /**
     * @param Context $context
     * @param \Magento\Checkout\Model\Session $checkoutSession
     * @param CustomerCart $cart
     */
    public function __construct(
        Context $context,
        \Magento\Checkout\Model\Session $checkoutSession,
        CustomerCart $cart,
        \Magento\Sales\Model\Order\AddressRepository $repositoryAddress
  /*      \Magento\Framework\ObjectManagerInterface $objectManager*/
    ) {
        $this->checkoutSession = $checkoutSession;
        $this->cart = $cart;
        $this->repositoryAddress = $repositoryAddress;
     /*   $this->_objectManager = $objectManager;*/
        parent::__construct($context);
    }

    public function execute()
    {
    	/*$order = $this->_objectManager->create('\Magento\Sales\Model\Order')->load('59');
		$region = $this->_objectManager->create('Magento\Directory\Model\Region')->load(49);
		$regionName = '';
        if ($region) {
            $regionName = $region->getName();
    	}
    	$billAddress = $this->repositoryAddress->get($order->getBillingAddressId());
    	$shippingAddress = $this->repositoryAddress->get($order->getShippingAddressId());
     	if($billAddress->getId()) {
               $billAddress->setFirstname($firstname);
               $billAddress->setLastname($lastname);
               $billAddress->setCountryId('US');
               $billAddress->setRegion($regionName);
               $billAddress->setRegionId($businessState);
               $billAddress->setPostcode($businessPincode);
               $billAddress->setStreet($businessSA1);
               $billAddress->setCity($businessCity);
               $billAddress->setTelephone($businessLocationPhonenumber);
               //print_r($shipAddress->getData());
               $this->repositoryAddress->save($billAddress);
           } 
   		die;*/
        $allItems = $this->checkoutSession->getQuote()->getAllVisibleItems();
        foreach ($allItems as $item) {
            $itemId = $item->getItemId();
            $this->cart->removeItem($itemId)->save();
        }
        $response = [
            'success' => true,
        ];

        $this->getResponse()->representJson(
            $this->_objectManager->get('Magento\Framework\Json\Helper\Data')->jsonEncode($response)
        );
    }
}