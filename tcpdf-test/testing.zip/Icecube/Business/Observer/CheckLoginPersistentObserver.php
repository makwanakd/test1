<?php
namespace Icecube\Business\Observer;
 
use Magento\Framework\Event\ObserverInterface;
use \Magento\Store\Model\StoreManagerInterface;
 
class CheckLoginPersistentObserver implements ObserverInterface
{

    protected $redirect;
    /*protected $_cmsPage;*/
    protected $storeManager;

    /**
     * Customer session
     *
     * @var \Magento\Customer\Model\Session
     */
    protected $_customerSession;

    public function __construct(
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Framework\App\Response\RedirectInterface $redirect,
         /*\Magento\Cms\Model\Page $cmsPage,*/
         StoreManagerInterface $storeManager

    ) {

        $this->_customerSession = $customerSession;
        $this->redirect = $redirect;
        //$this->_cmsPage = $cmsPage;
        $this->storeManager = $storeManager;

    }

    public function execute(\Magento\Framework\Event\Observer $observer)
    {
    	$finalurl = "";
        $om = \Magento\Framework\App\ObjectManager::getInstance();
        $storeManager = $om->get('\Magento\Store\Model\StoreManagerInterface');
        $base_url = $storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_WEB);
        $actionName = $observer->getEvent()->getRequest()->getFullActionName();
        $controller = $observer->getControllerAction();
        $url = $this->storeManager->getStore()->getCurrentUrl();
        if($actionName == 'cms_page_view'){
            $text = explode('/', $url, 2)[1];
            $finalurl = strtok($text, '?');
        }
         $base_url = explode('/', $base_url, 2)[1]; 
     if ($finalurl == ''.$base_url.'login' || $finalurl == ''.$base_url.'login/') { 
 		$customerSession = $om->get('Magento\Customer\Model\Session');
        $storeManager = $om->get('\Magento\Store\Model\StoreManagerInterface');
        $base_url = $storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_WEB);
		    if($customerSession->isLoggedIn()) {
		            $id = $customerSession->getCustomer()->getId(); 
		            $customerGroupid = $customerSession->getCustomer()->getGroupId(); 
		            if($customerGroupid == 4){
		                header('Location: '.$base_url.'profile/settings/');
		                exit();
		            }
		            else{

		                header('Location: '.$base_url.'customers/settings/');
		               exit();
		            }
		     }
		 }

    } 

}

    ?>