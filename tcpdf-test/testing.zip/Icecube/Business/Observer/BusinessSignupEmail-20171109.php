<?php
namespace Icecube\Business\Observer;
 
use Magento\Framework\Event\ObserverInterface;
use \Magento\Framework\Mail\Template\TransportBuilder;
use \Magento\Framework\Translate\Inline\StateInterface;
use \Magento\Store\Model\StoreManagerInterface;
 
class BusinessSignupEmail implements ObserverInterface
{
    const TEMPLATE_PATH = 'business_signup';
    const RECEIVER_EMAIL = 'magento.icecube@gmail.com';
    
    protected $_helper;
    
    protected $_api = null;

    protected $inlineTranslation;
    protected $transportBuilder;
	protected $_objectManager;
	protected $storeManager;
	protected $newsletterSession;
	protected $checkoutSession;
	protected $repositoryAddress;
	protected $packages;
	protected $customerRepositoryInterface;
	protected $addressRepository;
	
    public function __construct(
    StateInterface $inlineTranslation,
    TransportBuilder $transportBuilder,
    \Magento\Framework\ObjectManagerInterface $objectManager,
    StoreManagerInterface $storeManager,
    \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
    \Magento\Newsletter\Model\Session $newsletterSession, 
    \Magento\Checkout\Model\Session $checkoutSession,
    \Magento\Sales\Model\Order\AddressRepository $repositoryAddress,
    \Icecube\Business\Model\Data $packages,
    \Magento\Customer\Api\CustomerRepositoryInterface $customerRepositoryInterface,
    \Magento\Customer\Api\AddressRepositoryInterface $addressRepository,
    \Ebizmarts\MailChimp\Helper\Data $helper,
    array $data = [])
    {
        $this->inlineTranslation = $inlineTranslation;
        $this->_transportBuilder = $transportBuilder;
        $this->_objectManager = $objectManager;
        $this->storeManager = $storeManager;
        $this->_scopeConfig = $scopeConfig;
        $this->newsletterSession = $newsletterSession;
        $this->checkoutSession = $checkoutSession;
        $this->repositoryAddress= $repositoryAddress;
        $this->packages= $packages;
        $this->CustomerRepositoryInterface = $customerRepositoryInterface;
        $this->addressRepository = $addressRepository;
        $this->_helper          = $helper;
        $this->_api             = $this->_helper->getApi();
    }
    /**
     * customer register event handler
     *
     * @param \Magento\Framework\Event\Observer $observer
     * @return void
     */
    public function execute(\Magento\Framework\Event\Observer $observer) {
        $this->sendBusinessSignupMail();
    }
    public function sendBusinessSignupMail() {
		$templateOptions = array('area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => $this->storeManager->getStore()->getId());
		$customerId = $this->createBusinessUser();
		
		$templateVars = array( 
		                    'store' => $this->storeManager->getStore(),
		                    'customerid' => $customerId
		                );
		
		/*var_dump($_SESSION['business_data1']);
		die;*/
		//$orderId = 64;
		$orderId = $this->checkoutSession->getLastOrderId();
		
		$packageInfo = $this->getOrderItems($orderId);
		
		$stateInfo = $this->getStateValues();
		
		$_SESSION['current_package'] = $packageInfo;
		$_SESSION['state_info'] = $stateInfo;
		//$businessDatas = $this->newsletterSession->getBusinessData();
		$businessDatas = $_SESSION['business_data1'];
		$businessDatas = array_merge($templateVars, $businessDatas['basicinfo'], $businessDatas['location1'], $businessDatas['location2'], $businessDatas['location3'], $packageInfo, $stateInfo);
		
		$from = array('email' => $this->getSalesEmail(), 'name' => $this->getSalesName());
		$this->inlineTranslation->suspend();
		//$to = array(self::RECEIVER_EMAIL);
		
		$copyTo = $this->getCopyToIds();
		if($copyTo!=NULL && $copyTo!=''){
			$copyTo .= ','.$businessDatas['business-email'];
		}
		$copyTo = explode(',',$copyTo);
		//$to = array($businessDatas['business-email']);
		$transport = $this->_transportBuilder->setTemplateIdentifier(7)
		                ->setTemplateOptions($templateOptions)
		                ->setTemplateVars($businessDatas)
		                ->setFrom($from)
		                ->addTo($copyTo)
		                ->getTransport();
		$transport->sendMessage();
		$this->inlineTranslation->resume();
		
		
		
		$this->updateBillingAndShippingAddress($orderId,$customerId);
		$this->businessSubscription();
		
		header("Location: http://www.freeboxes.com/business/signup/success");
		exit();
		
	}
    public function getSalesEmail()
    {
        return $this->_scopeConfig->getValue(
            'trans_email/ident_sales/email',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }
    public function getCopyToIds()
    {
        return $this->_scopeConfig->getValue(
            'sales_email/order/copy_to',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }
    public function getSalesName()
    {
        return $this->_scopeConfig->getValue(
            'trans_email/ident_sales/name',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }
    public function createBusinessUser()
    {
    	$firstname = '';
		$lastname = '';
		$businessEmail = '';
		$businessName = '';
		$businessPhonenumber = '';
		$businessCategory = '';
		$businessPassword = '';
		$businessLocationName = '';
		$businessSA1 = '';
		$businessSA2 = '';
		$businessState = '';
		$businessLocationPhonenumber = '';
		$businessCity = '';
		$businessPincode = '';
		$businessWebsite = '';
		$businessLocationName2 = '';
		$businessSA12 = '';
		$businessSA22 = '';
		$businessState2 = '';
		$businessLocationPhonenumber2 = '';
		$businessCity2 = '';
		$businessPincode2 = '';
		$businessWebsite2 = '';
		$businessLocationName3 = '';
		$businessSA13 = '';
		$businessSA23 = '';
		$businessState3 = '';
		$businessLocationPhonenumber3 = '';
		$businessCity3 = '';
		$businessPincode3 = '';
		$businessWebsite3 = '';
		$sameAsShipping = '';
		
		
		//$businessDataFetch = $this->newsletterSession->getBusinessData();
		$businessDataFetch = $_SESSION['business_data1'];
		//var_dump($businessDataFetch);die;
		$basicInfo = $businessDataFetch['basicinfo'];
        $location1 = $businessDataFetch['location1'];
        $location2 = $businessDataFetch['location2'];
        $location3 = $businessDataFetch['location3'];

		if(isset($basicInfo['business-fname'])){
				$firstname = $basicInfo['business-fname'];
			}
			if(isset($basicInfo['business-lname'])){
				$lastname = $basicInfo['business-lname'];
			}
			
			if(isset($basicInfo['business-email'])){
				$businessEmail = $basicInfo['business-email'];
			}
			if(isset($basicInfo['business-name'])){
				$businessName = $basicInfo['business-name'];
			}
			if(isset($basicInfo['business-phonenumber'])){
				$businessPhonenumber = $basicInfo['business-phonenumber'];
			}
			if(isset($basicInfo['business-category'])){
				$businessCategory = $basicInfo['business-category'];
			}
			if(isset($basicInfo['password'])){
				$businessPassword = $basicInfo['password'];
			}		
			
				
			if(isset($location1['business-location-name'])){
				$businessLocationName = $location1['business-location-name'];
			}
			if(isset($location1['business-street-address-1'])){
				$businessSA1 = $location1['business-street-address-1'];
			}
			if(isset($location1['business-street-address-2'])){
				$businessSA2 = $location1['business-street-address-2'];
				if($businessSA2!=''){
					$businessSA1 .= "\n".$businessSA2;
				}
			}
			if(isset($location1['business-state'])){
				$businessState = $location1['business-state'];
			}
			if(isset($location1['business-location-phonenumber'])){
				$businessLocationPhonenumber = $location1['business-location-phonenumber'];
			}
			if(isset($location1['business-city'])){
				$businessCity = $location1['business-city'];
			}
			if(isset($location1['business-pincode'])){
				$businessPincode = $location1['business-pincode'];
			}
			if(isset($location1['business-pincode'])){
				$businessPincode = $location1['business-pincode'];
			}
			if(isset($location1['business-website'])){
				$businessWebsite = $location1['business-website'];
			}
			
			
			if(isset($location2['business-location-name2'])){
				$businessLocationName2 = $location2['business-location-name2'];
			}
			if(isset($location2['business-street-address-12'])){
				$businessSA12 = $location2['business-street-address-12'];
			}
			if(isset($location2['business-street-address-22'])){
				$businessSA22 = $location2['business-street-address-22'];
				if($businessSA22!=''){
					$businessSA12 .= "\n".$businessSA22;
				}
			}
			if(isset($location2['business-state2'])){
				$businessState2 = $location2['business-state2'];
			}
			if(isset($location2['business-location-phonenumber2'])){
				$businessLocationPhonenumber2 = $location2['business-location-phonenumber2'];
			}
			if(isset($location2['business-city2'])){
				$businessCity2 = $location2['business-city2'];
			}
			if(isset($location2['business-pincode2'])){
				$businessPincode2 = $location2['business-pincode2'];
			}
			if(isset($location2['business-website2'])){
				$businessWebsite2 = $location2['business-website2'];
			}
			
			
			if(isset($location3['business-location-name3'])){
				$businessLocationName3 = $location3['business-location-name3'];
			}
			if(isset($location3['business-street-address-13'])){
				$businessSA13 = $location3['business-street-address-13'];
			}
			if(isset($location3['business-street-address-23'])){
				$businessSA23 = $location3['business-street-address-23'];
				if($businessSA23!=''){
					$businessSA13 .= "\n".$businessSA23;
				}
			}
			if(isset($location3['business-state3'])){
				$businessState3 = $location3['business-state3'];
			}
			if(isset($location3['business-location-phonenumber3'])){
				$businessLocationPhonenumber3 = $location3['business-location-phonenumber3'];
			}
			if(isset($location3['business-city3'])){
				$businessCity3 = $location3['business-city3'];
			}
			if(isset($location3['business-pincode3'])){
				$businessPincode3 = $location3['business-pincode3'];
			}
			if(isset($location3['business-website3'])){
				$businessWebsite3 = $location3['business-website3'];
			}
			
			if(isset($basicInfo['same-as-shipping'])){
				$sameAsShipping = $basicInfo['same-as-shipping'];
			}

        $objectManager1 = \Magento\Framework\App\ObjectManager::getInstance();	 
		$customerFactory = $objectManager1->get('\Magento\Customer\Model\CustomerFactory');		 
		$websiteId = $this->storeManager->getWebsite()->getWebsiteId();	 	 
		// Instantiate object (this is the most important part)		 
		$customer = $customerFactory->create();		 
		$customer->setWebsiteId($websiteId);		 
		$customer->setEmail($businessEmail);		 
		$customer->setFirstname($firstname);		 
		$customer->setLastname($lastname);		 
		//$customer->setBusinessCategory($businessCategory);
		$customer->setGroupId(4);
		//$customer->setBusinessName($businessName);
		//$customer->setData('business_name',$businessName);
		//$customer->setBusinessPhoneNumberCheckout($businessPhonenumber);
		$customer->setPassword($businessPassword);
		
		//$customer->setCustomAttribute('business_phone_number_checkout', $businessPhonenumber);
		$customer->save();		 
		//echo 'Create customer successfully'.$customer->getId();
        
        //////////////update info//////////
        $customerUpdate = $this->CustomerRepositoryInterface->getById($customer->getId());
		$customerUpdate->setCustomAttribute('business_phone_number_checkout', $businessPhonenumber);
		$customerUpdate->setCustomAttribute('business_name', $businessName);
		$customerUpdate->setCustomAttribute('business_category', $businessCategory);
		$this->CustomerRepositoryInterface->save($customerUpdate);
        
        /*
        die;*/
        /*----------------------------------*/
        if($businessLocationName!=''){
        	$objectManager2 = \Magento\Framework\App\ObjectManager::getInstance();	 
			$addresss = $objectManager2->get('\Magento\Customer\Model\AddressFactory');
			$address = $addresss->create();
			$address->setCustomerId($customer->getId())
			->setFirstname($firstname)
			->setLastname($lastname)
			->setCountryId('US')
			->setPostcode($businessPincode)
			->setCity($businessCity)
			->setTelephone($businessLocationPhonenumber)
			->setStreet($businessSA1)
			->setRegionId($businessState)
			->setLocationName($businessLocationName)
			->setWebsiteName($businessWebsite)
			->setIsDefaultBilling('1')
			->setIsDefaultShipping('1')
			->setSaveInAddressBook('1');
			$address->save();
			
			$addressUpdate = $this->addressRepository->getById($address->getId());
			$addressUpdate->setCustomAttribute('location_name', $businessLocationName);
			$addressUpdate->setCustomAttribute('website_name', $businessWebsite);
			$this->addressRepository->save($addressUpdate);
			
		}
		if($businessLocationName2!=''){
			$objectManager3 = \Magento\Framework\App\ObjectManager::getInstance();	 
			$addresss2 = $objectManager3->get('\Magento\Customer\Model\AddressFactory');
			$address = $addresss2->create();
			$address->setCustomerId($customer->getId())
			->setFirstname($firstname)
			->setLastname($lastname)
			->setCountryId('US')
			->setPostcode($businessPincode2)
			->setCity($businessCity2)
			->setTelephone($businessLocationPhonenumber2)
			->setStreet($businessSA12)
			->setRegionId($businessState2)
			->setLocationName($businessLocationName2)
			->setWebsiteName($businessWebsite2)
			->setSaveInAddressBook('1');
			$address->save();
			
			$addressUpdate = $this->addressRepository->getById($address->getId());
			$addressUpdate->setCustomAttribute('location_name', $businessLocationName2);
			$addressUpdate->setCustomAttribute('website_name', $businessWebsite2);
			$this->addressRepository->save($addressUpdate);
			
		}
		if($businessLocationName3!=''){
			$objectManager4 = \Magento\Framework\App\ObjectManager::getInstance();	 
			$addresss3 = $objectManager4->get('\Magento\Customer\Model\AddressFactory');
			$address = $addresss3->create();
			$address->setCustomerId($customer->getId())
			->setFirstname($firstname)
			->setLastname($lastname)
			->setCountryId('US')
			->setPostcode($businessPincode3)
			->setCity($businessCity3)
			->setTelephone($businessLocationPhonenumber3)
			->setStreet($businessSA13)
			->setRegionId($businessState3)
			->setLocationName($businessLocationName3)
			->setWebsiteName($businessWebsite3)
			->setSaveInAddressBook('1');
			$address->save();
			
			$addressUpdate = $this->addressRepository->getById($address->getId());
			$addressUpdate->setCustomAttribute('location_name', $businessLocationName3);
			$addressUpdate->setCustomAttribute('website_name', $businessWebsite3);
			$this->addressRepository->save($addressUpdate);
			
		}
		return $customer->getId();
    }
    public function getStateValues()
    {
    	$stateInfoTemp = array();
		$businessState = '';
		$businessState2 = '';
		$businessState3 = '';
		$businessCategory = '';
		
		
		//$businessDataFetch = $this->newsletterSession->getBusinessData();
		$businessDataFetch = $_SESSION['business_data1'];
		$basicInfo = $businessDataFetch['basicinfo'];
		//var_dump($businessDataFetch);die;
		$location1 = $businessDataFetch['location1'];
        $location2 = $businessDataFetch['location2'];
        $location3 = $businessDataFetch['location3'];

		if(isset($basicInfo['business-category'])){
			$businessCategory = $basicInfo['business-category'];
		}
		
		$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
		$category = $objectManager->create('\Icecube\Extrafields\Model\Category\Types')->getAllOptions();
		foreach($category as $c){
			if($businessCategory==$c['value']){
				$businessCategory = $c['label'];
				$stateInfoTemp['business-category-label'] = $businessCategory;
				break;
			}			
		}
		
		if(isset($location1['business-state'])){
			$businessState = $location1['business-state'];
		}
		if(isset($location2['business-state2'])){
			$businessState2 = $location2['business-state2'];
		}
		if(isset($location3['business-state3'])){
			$businessState3 = $location3['business-state3'];
		}
		if($businessState!='' && $businessState!=NULL){
			$region = $this->_objectManager->create('Magento\Directory\Model\Region')->load($businessState);
			$regionName = '';
	        if ($region) {
	            $regionName = $region->getName();
	    	}
	    	$stateInfoTemp['statename1'] = $regionName;
		}
		if($businessState2!='' && $businessState2!=NULL){
			$region = $this->_objectManager->create('Magento\Directory\Model\Region')->load($businessState2);
			$regionName = '';
	        if ($region) {
	            $regionName = $region->getName();
	    	}
	    	$stateInfoTemp['statename2'] = $regionName;
		}
		if($businessState3!='' && $businessState3!=NULL){
			$region = $this->_objectManager->create('Magento\Directory\Model\Region')->load($businessState3);
			$regionName = '';
	        if ($region) {
	            $regionName = $region->getName();
	    	}
	    	$stateInfoTemp['statename3'] = $regionName;
		}
		return $stateInfoTemp;
    }
	public function updateBillingAndShippingAddress($orderId,$customerId)
    {
    	$firstname = '';
		$lastname = '';
		$businessEmail = '';
		$businessName = '';
		$businessPhonenumber = '';
		$businessCategory = '';
		$businessPassword = '';
		$businessLocationName = '';
		$businessSA1 = '';
		$businessSA2 = '';
		$businessState = '';
		$businessLocationPhonenumber = '';
		$businessCity = '';
		$businessPincode = '';
		$businessWebsite = '';
		$businessLocationName2 = '';
		$sameAsShipping = '';
		
		$businessDataFetch = $_SESSION['business_data1'];
		//$businessDataFetch = $this->newsletterSession->getBusinessData();
		//var_dump($businessDataFetch);die;
		$basicInfo = $businessDataFetch['basicinfo'];
        $location1 = $businessDataFetch['location1'];
        $location2 = $businessDataFetch['location2'];
        $location3 = $businessDataFetch['location3'];

			if(isset($basicInfo['business-fname'])){
				$firstname = $basicInfo['business-fname'];
			}
			if(isset($basicInfo['business-lname'])){
				$lastname = $basicInfo['business-lname'];
			}
			
			if(isset($basicInfo['business-email'])){
				$businessEmail = $basicInfo['business-email'];
			}
			if(isset($basicInfo['business-name'])){
				$businessName = $basicInfo['business-name'];
			}
			if(isset($basicInfo['business-phonenumber'])){
				$businessPhonenumber = $basicInfo['business-phonenumber'];
			}
			if(isset($basicInfo['business-category'])){
				$businessCategory = $basicInfo['business-category'];
			}
			if(isset($basicInfo['password'])){
				$businessPassword = $basicInfo['password'];
			}
			if(isset($basicInfo['same-as-shipping'])){
				$sameAsShipping = $basicInfo['same-as-shipping'];
			}		
			
				
			if(isset($location1['business-location-name'])){
				$businessLocationName = $location1['business-location-name'];
			}
			if(isset($location1['business-street-address-1'])){
				$businessSA1 = $location1['business-street-address-1'];
			}
			if(isset($location1['business-street-address-2'])){
				$businessSA2 = $location1['business-street-address-2'];
				if($businessSA2!=''){
					$businessSA1 .= "\n".$businessSA2;
				}
			}
			if(isset($location1['business-state'])){
				$businessState = $location1['business-state'];
			}
			if(isset($location1['business-location-phonenumber'])){
				$businessLocationPhonenumber = $location1['business-location-phonenumber'];
			}
			if(isset($location1['business-city'])){
				$businessCity = $location1['business-city'];
			}
			if(isset($location1['business-pincode'])){
				$businessPincode = $location1['business-pincode'];
			}
			if(isset($location1['business-pincode'])){
				$businessPincode = $location1['business-pincode'];
			}
			if(isset($location1['business-website'])){
				$businessWebsite = $location1['business-website'];
			}
			
			
			$order = $this->_objectManager->create('\Magento\Sales\Model\Order')->load($orderId);
			$order->setCustomerId($customerId);
			$order->setCustomerIsGuest(0);
			$order->setCustomerFirstname($firstname);
			$order->setCustomerLastname($lastname);
			$order->setCustomerGroupId(4);
			$order->save();
			
			
			/*if(!$order->getShippingAddressId()){
				$shipAddress = $this->repositoryAddress->get($order->getShippingAddressId());
				if($shipAddress->getId())
		        {
		        	$shipAddress = $this->repositoryAddress->create();
		            $shipAddress->setFirstname($firstname);
		            $shipAddress->setLastname($lastname);
		            $shipAddress->setCountryId('US');
		            $shipAddress->setRegion('teee');
		            $shipAddress->setParentId(64);		            
		            $shipAddress->setRegionId($businessState);
		            $shipAddress->setPostcode($businessPincode);
		            $shipAddress->setStreet($businessSA1);
		            $shipAddress->setCity($businessCity);
		            $shipAddress->setTelephone($businessLocationPhonenumber);
		            //print_r($shipAddress->getData());
		            $this->repositoryAddress->save($shipAddress);
		        //} 
			}
			*/
    		$region = $this->_objectManager->create('Magento\Directory\Model\Region')->load($businessState);
			$regionName = '';
            if ($region) {
                $regionName = $region->getName();
        	}
	    	if($sameAsShipping=="1" || $sameAsShipping=="on"){
	    		if($order->getBillingAddressId()){
					$billAddress = $this->repositoryAddress->get($order->getBillingAddressId());
					if($billAddress->getId())
			        {
			            $billAddress->setFirstname($firstname);
			            $billAddress->setLastname($lastname);
			            $billAddress->setCountryId('US');
			            $billAddress->setRegion($regionName);
			            $billAddress->setRegionId($businessState);
			            $billAddress->setPostcode($businessPincode);
			            $billAddress->setStreet($businessSA1);
			            $billAddress->setCity($businessCity);
			            $billAddress->setTelephone($businessLocationPhonenumber);
			            //print_r($shipAddress->getData());
			            $this->repositoryAddress->save($billAddress);
			        } 
				}
			}
			//unset($_SESSION['business_data1']);		
    }
    public function getOrderItems($orderId)
    {
    	//$orderId = $this->checkoutSession->getLastOrderId();
		$order = $this->_objectManager->create('\Magento\Sales\Model\Order')->load($orderId);
		
		$items = $order->getAllVisibleItems();
		$packageInfo = array();
		$currentPackage = '';
		foreach($items as $item) {
			$options = $item->getProductOptions();
		    if (isset($options['options']) && !empty($options['options'])) {
		        foreach ($options['options'] as $option) {
		          $currentPackage = $option['value'];
				}
		    }
		}
		foreach($this->packages->collectionFactory() as $allpackages){
			if($allpackages->getName()==$currentPackage){
				$packageInfo['package_name'] = $allpackages->getName();
	            $packageInfo['mr_boxes'] = number_format($allpackages->getBoxCount());
	            $packageInfo['box_advertisements'] = number_format($allpackages->getBoxAdvertisementsCount());
	            $packageInfo['business_profile_pages'] = number_format($allpackages->getBusinessProfilePages());
	            $packageInfo['coupon_landing_pages'] = number_format($allpackages->getBusinessLandingPages());
	            $packageInfo['online_ad_placements'] = number_format($allpackages->getOnlineAdPlacement());
	            break;
			}
		}
		return $packageInfo;
	}
	public function businessSubscription(){
		
		$firstname = '';
		$lastname = '';
		$businessEmail = '';
		$businessName = '';
		$businessPhonenumber = '';
		$businessCategory = '';		
		$subscribeme = '';		
		
		$businessDataFetch = $_SESSION['business_data1'];
		$basicInfo = $businessDataFetch['basicinfo'];

		if(isset($basicInfo['business-fname'])){
			$firstname = $basicInfo['business-fname'];
		}
		if(isset($basicInfo['business-lname'])){
			$lastname = $basicInfo['business-lname'];
		}
		
		if(isset($basicInfo['business-email'])){
			$businessEmail = $basicInfo['business-email'];
		}
		if(isset($basicInfo['business-name'])){
			$businessName = $basicInfo['business-name'];
		}
		if(isset($basicInfo['business-phonenumber'])){
			$businessPhonenumber = $basicInfo['business-phonenumber'];
		}
		if(isset($basicInfo['business-category'])){
			$businessCategory = $basicInfo['business-category'];
		}
		if(isset($basicInfo['subscribeme'])){
			$subscribeme = $basicInfo['subscribeme'];
		}
		
		$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
		$category = $objectManager->create('\Icecube\Extrafields\Model\Category\Types')->getAllOptions();
		foreach($category as $c){
			if($businessCategory==$c['value']){
				$businessCategory = $c['label'];
				break;
			}			
		}
		$email = $businessEmail;
		$telephone = $businessPhonenumber;
		$finalNumber = '';
		if($telephone!=NULL && $telephone!=''){
			$telephone = str_replace(' ','',$telephone);
			$telephone = str_replace('-','',$telephone);
			$telephone = str_replace('(','',$telephone);
			$telephone = str_replace(')','',$telephone);
			
			if(strlen($telephone)==10){
				$finalNumber = substr($telephone,0,3);
				$finalNumber .= '-';
				$finalNumber .= substr($telephone,3,3);
				$finalNumber .= '-';
				$finalNumber .= substr($telephone,6,4);
			}
		}		            
        $mergeVars = array("MMERGE3" => $businessName, "MMERGE5" => $businessCategory, "FNAME" => $firstname, "LNAME" => $lastname, "PHONE" => $finalNumber);
        $api = $this->_api;
        
        //$status = 'pending';
        $status = 'subscribed';
        $emailHash = md5(strtolower($email));
        if($subscribeme=="1" || $subscribeme=="on"){
	    	try {
	            $return = $api->lists->members->addOrUpdate('a0d91bbaf2', $emailHash, null, $status, $mergeVars, null, null, null, null, $email, $status);
	        } catch (\Exception $e) {
	            $this->_helper->log($e->getMessage());
	        }
		}
	}
}