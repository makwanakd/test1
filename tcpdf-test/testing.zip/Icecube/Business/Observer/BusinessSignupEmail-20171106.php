<?php
namespace Icecube\Business\Observer;
 
use Magento\Framework\Event\ObserverInterface;
use \Magento\Framework\Mail\Template\TransportBuilder;
use \Magento\Framework\Translate\Inline\StateInterface;
use \Magento\Store\Model\StoreManagerInterface;
 
class BusinessSignupEmail implements ObserverInterface
{
    const TEMPLATE_PATH = 'business_signup';
    const RECEIVER_EMAIL = 'magento.icecube@gmail.com';

    protected $inlineTranslation;
    protected $transportBuilder;
	protected $_objectManager;
	protected $storeManager;
    public function __construct(
    StateInterface $inlineTranslation,
    TransportBuilder $transportBuilder,
    \Magento\Framework\ObjectManagerInterface $objectManager,
    StoreManagerInterface $storeManager,
    \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig, 
    array $data = [])
    {
        $this->inlineTranslation = $inlineTranslation;
        $this->_transportBuilder = $transportBuilder;
        $this->_objectManager = $objectManager;
        $this->storeManager = $storeManager;
        $this->_scopeConfig = $scopeConfig;
    }
    /**
     * customer register event handler
     *
     * @param \Magento\Framework\Event\Observer $observer
     * @return void
     */
    public function execute(\Magento\Framework\Event\Observer $observer) {
        $this->sendBusinessSignupMail();
    }
    public function sendBusinessSignupMail() {
		$templateOptions = array('area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => $this->storeManager->getStore()->getId());
		$templateVars = array(
		                    'store' => $this->storeManager->getStore(),
		                    'customer_name' => 'John Doe',
		                    'message'   => 'Hello World!!.'
		                );
		$from = array('email' => $this->getSalesEmail(), 'name' => $this->getSalesName());
		$this->inlineTranslation->suspend();
		$to = array(self::RECEIVER_EMAIL);
		$transport = $this->_transportBuilder->setTemplateIdentifier(self::TEMPLATE_PATH)
		                ->setTemplateOptions($templateOptions)
		                ->setTemplateVars($templateVars)
		                ->setFrom($from)
		                ->addTo($to)
		                ->getTransport();
		$transport->sendMessage();
		$this->inlineTranslation->resume();
	}
    public function getSalesEmail()
    {
        return $this->_scopeConfig->getValue(
            'trans_email/ident_sales/email',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }
    public function getSalesName()
    {
        return $this->_scopeConfig->getValue(
            'trans_email/ident_sales/name',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }
}