<?php
/**
 * Copyright � 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Icecube\Business\Block\Frontend;

/**
 * Order item render block
 */
class Businesssignup extends \Icecube\Business\Model\Data
{
	
}
?>