<?php
/**
 * Icecube Business Extension 
 * 
 * Icecube_Business
 * 
 * PHP version 5.x
 *
 * @category  TemplatestatusActions
 * @preference   Icecube_Business
 * @author    Icecube Digital <support@icecubedigital.com>
 * @copyright 2016 Icecube Digital
 * @license   http://www.php.net/license/3_01.txt  PHP License 3.01
 * @link      http://www.icecubedigital.com
 */
namespace Icecube\Business\Ui\Component\Listing\Column;

use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Ui\Component\Listing\Columns\Column;
use Magento\Framework\UrlInterface;
/**
 * Icecube_Business
 *
 * @category  TemplatestatusActions
 * @preference   Icecube_Business
 * @author    Icecube Digital <support@icecubedigital.com>
 * @copyright 2016 Icecube Digital
 * @license   http://www.php.net/license/3_01.txt  PHP License 3.01
 * @link      http://www.icecubedigital.com
 */
class PreferenceStatus extends Column
{
    /** Url path */
    const BLOG_URL_PATH_EDIT = 'business/preferences/edit';
    const BLOG_URL_PATH_DELETE = 'business/preferences/delete';

    /** @var UrlInterface */
    protected $urlBuilder;

    /**
     * @var string
     */
    private $editUrl;

    /**
     * Constructure 
     * 
     * @param ContextInterface $context Context
     * @param UiComponentFactory $uiComponentFactory UI Component Factory
     * @param UrlInterface $urlBuilder Url builder
     * @param array $components Components
     * @param array $data Data
     * @param string $editUrl Edit Url
     */
    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        UrlInterface $urlBuilder,
        array $components = [],
        array $data = [],
        $editUrl = self::BLOG_URL_PATH_EDIT
    ) {
        $this->urlBuilder = $urlBuilder;
        $this->editUrl = $editUrl;
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    /**
     * Prepare Data Source
     *
     * @param array $dataSource
     * @return array
     */
    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
           $fieldName = $this->getData('name');
           foreach ($dataSource['data']['items'] as & $item) { 
	       	   if ($item[$fieldName] == 1) :
	       			$item[$fieldName] = 'Enable';
	       	   else:
	       	   		$item[$fieldName] = 'Disable';
	       	   endif;		
           }
        }
        return $dataSource;
    }
}
