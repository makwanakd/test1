<?php
/**
 * Copyright � 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Icecube\Business\Model;

/**
 * Order item render block
 */
class Data extends \Magento\Framework\View\Element\Template
{
	public $_storeManager;
	public $_preferencesManager;
	public $_countryInformationAcquirer;
	public $_objectManager;
	public $_packageManager;
	public $_productLoader;
	public function __construct(
									\Magento\Framework\View\Element\Template\Context $context,
									\Icecube\Business\Model\ResourceModel\Preferences\CollectionFactory $preferencesCollection,
									\Icecube\Business\Model\ResourceModel\Packages\CollectionFactory $packageManager,
									\Magento\Directory\Api\CountryInformationAcquirerInterface $countryInformationAcquirer,
									\Magento\Framework\ObjectManagerInterface $objectmanager,
									\Magento\Catalog\Model\Product $productLoader,
									\Magento\Catalog\Block\Product\ListProduct $listProduct
							   )
	{
		parent::__construct($context);
		$this->_storeManager = $context->getStoreManager();
		$this->_preferencesManager = $preferencesCollection;
		$this->_countryInformationAcquirer = $countryInformationAcquirer;
		$this->_objectManager = $objectmanager;
		$this->_packageManager = $packageManager;
		$this->_productLoader = $productLoader;
		$this->_listProduct = $listProduct;
	}

	public function getBaseUrl() {
		return $this->_storeManager->getStore()->getBaseUrl();
	}
	public function getMediaUrl() {
		return $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
	}
	public function getPreferences() {
		return $this->_preferencesManager->create()->load();
	}
	public function collectionFactory() { 
		return $this->_packageManager->create()->load();
	}
	public function getStates()
	{
	    $regions = [];
	    $countries = $this->_countryInformationAcquirer->getCountriesInfo();
	    foreach ($countries as $country) {
	        // Get regions for this country:
	        if($country->getId() == "US"):
		        if ($availableRegions = $country->getAvailableRegions()) {
		            foreach ($availableRegions as $region) {
		                $regions[] = [
		                    'id'   => $region->getId(),
		                    'code' => $region->getCode(),
		                    'name' => $region->getName()
		                ];
		            }
		        }
	        endif;
	    }

	    return $regions;
	}
	public function loadProduct($product_id) {
		return $this->_productLoader->load($product_id);
	}
	public function getAddToCartParam($product)
    {
        return $this->_listProduct->getAddToCartPostParams($product);
    }
}
?>