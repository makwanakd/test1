var config = {
 	map: {
 		"*": {
 			"jquery.bootstrap": "Icecube_Bootstrap/js/bootstrap",
 			"jquery.easing": 'Icecube_Bootstrap/js/jquery.easing.min',
 			"jquery.touch": 'Icecube_Bootstrap/js/jquery.touchSwipe.min',
 			"jquery.liquid": 'Icecube_Bootstrap/js/jquery.liquid-slider.min',
 		}
 	},
    shim: {
        'jquery.bootstrap': {
            'deps': ['jquery']
        },
        'jquery.easing': {
            'deps': ['jquery']
        },
        'jquery.touch': {
            'deps': ['jquery']
        },
        'jquery.liquid': {
            'deps': ['jquery']
        }
    }
};