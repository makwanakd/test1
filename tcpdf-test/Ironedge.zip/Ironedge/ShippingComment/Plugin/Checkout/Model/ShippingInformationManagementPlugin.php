<?php
namespace Ironedge\ShippingComment\Plugin\Checkout\Model;

class ShippingInformationManagementPlugin {

    protected $quoteRepository;

    /**
     * 
     * @param \Magento\Quote\Model\QuoteRepository $quoteRepository
     */
    public function __construct(
	\Psr\Log\LoggerInterface $logger,
    \Magento\Quote\Model\QuoteRepository $quoteRepository
    ) {
		$this->_logger = $logger;
        $this->quoteRepository = $quoteRepository;
    }

    /**
     * 
     * @param \Magento\Checkout\Model\ShippingInformationManagement $subject
     * @param type $cartId
     * @param \Magento\Checkout\Api\Data\ShippingInformationInterface $addressInformation
     */
    public function beforeSaveAddressInformation(
    \Magento\Checkout\Model\ShippingInformationManagement $subject, $cartId, \Magento\Checkout\Api\Data\ShippingInformationInterface $addressInformation
    ) {
        $extAttributes = $addressInformation->getExtensionAttributes();
		$deliveryComment = $extAttributes->getDeliveryComment();
		$quote = $this->quoteRepository->getActive($cartId);
        $quote->setDeliveryComment($deliveryComment);
    }

}
