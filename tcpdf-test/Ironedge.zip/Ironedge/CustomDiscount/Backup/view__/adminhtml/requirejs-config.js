var config = {
    map: {
        '*': {
            'Magento_Sales/order/create/scripts': 'Ironedge_CustomDiscount/js/order/create/scripts'
        }
    }
};