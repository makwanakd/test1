<?php
/**
 * Copyright © 2013-2017 Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Ironedge\CustomDiscount\Block\Adminhtml\Sales\Order\Create;


use Magento\Framework\Pricing\PriceCurrencyInterface;
/**
 * Adminhtml sales order create coupons block
 *
 * @author      Magento Core Team <core@magentocommerce.com>
 */
class CustomDiscount extends \Magento\Sales\Block\Adminhtml\Order\Create\AbstractCreate
{
    /**
     * Tax configuration model
     *
     * @var \Magento\Tax\Model\Config
     */
    protected $_config;

    /**
     * @var Order
     */
    protected $_order;

    protected $_quote;

    /**
     * @var \Magento\Framework\DataObject
     */
    protected $_source;

    /**
     * Order create
     *
     * @var \Magento\Sales\Model\AdminOrder\Create
     */
    protected $_orderCreate;

    /**
     * @var PriceCurrencyInterface
     */
    protected $priceCurrency;

    protected $quoteFactory;

    /**
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Magento\Tax\Model\Config $taxConfig
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Backend\Model\Session\Quote $quote,
        \Magento\Quote\Model\QuoteFactory $quoteFactory,
        \Magento\Sales\Model\AdminOrder\Create $orderCreate,
        PriceCurrencyInterface $priceCurrency,
        \Magento\Tax\Model\Config $taxConfig,
        array $data = []
    ) {
        $this->_config = $taxConfig;
        $this->quoteFactory = $quoteFactory;
        $this->_quote = $quote;
        parent::__construct($context, $quote, $orderCreate, $priceCurrency, $data);
    }

    /**
     * Constructor
     *
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->setId('sales_order_create_custom_discount_form');
    }

    /**
     * Get header text
     *
     * @return \Magento\Framework\Phrase
     */
    public function getHeaderText()
    {
        return __('Custom Discount');
    }

    /**
     * Get header css class
     *
     * @return string
     */
    public function getHeaderCssClass()
    {
        return 'head-custom-discount-quote';
    }

    /**
     * Check if we nedd display full tax total info
     *
     * @return bool
     */
    public function displayFullSummary()
    {
        return true;
    }

    /**
     * Get data (totals) source model
     *
     * @return \Magento\Framework\DataObject
     */
    public function getSource()
    {
        return $this->_source;
    } 
    public function getStore()
    {
        return $this->_order->getStore();
    }

      /**
     * @return Order
     */
    public function getOrder()
    {
        return $this->_order;
    }

    /**
     * @return array
     */
    public function getLabelProperties()
    {
        return $this->getParentBlock()->getLabelProperties();
    }
	
	public function getQuote()
	{
		$quote = $this->quoteFactory->create()->load($this->_quote->getQuoteId());
		
		return $quote;
	}

	public function getDiscountType()
    {
        $quote = $this->getQuote();
        
		return $quote->getDiscountType();
    }
	
	public function getDiscountValue()
    {
        $quote = $this->getQuote();
        if($quote->getDiscountValue() > 0)
		{
			return $quote->getDiscountValue();
		}
		
		return;
    }
	
    public function getCustomDiscount()
    {
        $quote = $this->getQuote();
        if($quote->getCustomDiscount() > 0){
            $customDiscount  = $quote->getCustomDiscount();
            return $customDiscount;
        }
        
        return;
    }

    /**
     * @return array
     */
    public function getValueProperties()
    {
        return $this->getParentBlock()->getValueProperties();
    }

    /**
     * Initialize all order totals relates with tax
     *
     * @return \Magento\Tax\Block\Sales\Order\Tax
     */
     public function initTotals()
    {
        $parent = $this->getParentBlock();
        $this->_order = $parent->getOrder();
        $this->_source = $parent->getSource();

        $store = $this->getStore();

        $customDiscount = $this->_order->getCustomDiscount();
        
        $customDiscountRow = new \Magento\Framework\DataObject(
                [
                    'code' => 'customdiscount',
                    'strong' => false,
                    'value' => $customDiscount,
                    'label' => __('Custom Discount'),
                ]
            );

        $parent->addTotal($customDiscountRow, 'customdiscount');
       
        return $this;
    }
}
