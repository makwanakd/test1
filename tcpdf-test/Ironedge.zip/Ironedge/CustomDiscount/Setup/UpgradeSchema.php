<?php
/**
* Magedelight
* Copyright (C) 2016 Magedelight <info@magedelight.com>
*
* @category Magedelight
* @package Magedelight_Giftwrapper
* @copyright Copyright (c) 2016 Mage Delight (http://www.magedelight.com/)
* @license http://opensource.org/licenses/gpl-3.0.html GNU General Public License,version 3 (GPL-3.0)
* @author Magedelight <info@magedelight.com>
*/
namespace Ironedge\CustomDiscount\Setup;

use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

/**
 * @codeCoverageIgnore
 */
class UpgradeSchema implements UpgradeSchemaInterface {

    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context) {
        $installer = $setup;

        $installer->startSetup();
        if (version_compare($context->getVersion(), '1.0.2') < 0) {   
			$installer->getConnection()->addColumn(
			$installer->getTable('quote'),
				'custom_discount',
				[
					'type' => \Magento\Framework\DB\Ddl\Table::TYPE_DECIMAL,
					'length' => '12,4',
					'unsigned' => true,
					'nullable' => true,
					'default' => '0.0000',
					'comment' => 'Custom Discount'
				]
			);
	
			$installer->getConnection()->addColumn(
			$installer->getTable('sales_order'),
				'custom_discount',
				[
					'type' => \Magento\Framework\DB\Ddl\Table::TYPE_DECIMAL,
					'length' => '12,4',
					'unsigned' => true,
					'nullable' => true,
					'default' => '0.0000',
					'comment' => 'Custom Discount'
				]
			);
		}
		
		if (version_compare($context->getVersion(), '1.0.3') < 0) {   
			$installer->getConnection()->addColumn(
			$installer->getTable('quote'),
				'discount_type',
				[
					'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
					'length' => '128',
					'nullable' => true,
					'default' => 'fixed_amount',
					'comment' => 'Custom Discount Type'
				]
			);
			
			$installer->getConnection()->addColumn(
			$installer->getTable('quote'),
				'discount_value',
				[
					'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
					'length' => '128',
					'nullable' => true,
					'default' => '0.0000',
					'comment' => 'Custom Discount Value'
				]
			);
	
			$installer->getConnection()->addColumn(
			$installer->getTable('sales_order'),
				'discount_type',
				[
					'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
					'length' => '128',
					'nullable' => true,
					'default' => 'fixed_amount',
					'comment' => 'Custom Discount Type'
				]
			);
			
			$installer->getConnection()->addColumn(
			$installer->getTable('sales_order'),
				'discount_value',
				[
					'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
					'length' => '128',
					'nullable' => true,
					'default' => '0.0000',
					'comment' => 'Custom Discount Value'
				]
			);
		}

        $installer->endSetup();
    }

}
