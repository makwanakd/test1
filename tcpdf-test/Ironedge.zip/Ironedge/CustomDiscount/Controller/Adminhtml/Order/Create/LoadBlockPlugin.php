<?php

namespace Ironedge\CustomDiscount\Controller\Adminhtml\Order\Create;

class LoadBlockPlugin
{
    public function afterExecute($subject, $result)
    {
    	return $result; //['(' . $result . ')'];
    }
}
?>