<?php
/**
* Magedelight
* Copyright (C) 2016 Magedelight <info@magedelight.com>
*
* @category Magedelight
* @package Magedelight_Giftwrapper
* @copyright Copyright (c) 2016 Mage Delight (http://www.magedelight.com/)
* @license http://opensource.org/licenses/gpl-3.0.html GNU General Public License,version 3 (GPL-3.0)
* @author Magedelight <info@magedelight.com>
*/

namespace Ironedge\CustomDiscount\Model\Total\Creditmemo;

use Magento\Sales\Model\Order\Creditmemo;

class CustomDiscount extends \Magento\Sales\Model\Order\Creditmemo\Total\AbstractTotal
{
    /**
     * Collect Giftwrapper Initial amounts for the credit memo.
     *
     * @param Creditmemo $creditmemo
     *
     * @return $this
     * @SuppressWarnings(PHPMagedelight.CyclomaticComplexity)
     * @SuppressWarnings(PHPMagedelight.NPathComplexity)
     * @SuppressWarnings(PHPMagedelight.ExcessiveMethodLength)
     * @SuppressWarnings(PHPMagedelight.UnusedLocalVariable)
     */
    public function collect(Creditmemo $creditmemo)
    {
        $store = $creditmemo->getStore();
        $order = $creditmemo->getOrder();

        $customDiscount = $order->getCustomDiscount();
        
        $totalInitialAmount = 0;
        $baseTotalInitialAmount = 0;

        $totalInitialAmount = $customDiscount;
        $baseTotalInitialAmount = $customDiscount;

        $creditmemo->setTaxAmount($creditmemo->getTaxAmount());
        $creditmemo->setBaseTaxAmount($creditmemo->getBaseTaxAmount());

        $creditmemo->setGrandTotal($creditmemo->getGrandTotal() - $totalInitialAmount);
        $creditmemo->setBaseGrandTotal($creditmemo->getBaseGrandTotal() - $totalInitialAmount);

        return $this;
    }
}
