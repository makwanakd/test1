<?php

/**
* Magedelight
* Copyright (C) 2016 Magedelight <info@magedelight.com>
*
* @category Magedelight
* @package Magedelight_Giftwrapper
* @copyright Copyright (c) 2016 Mage Delight (http://www.magedelight.com/)
* @license http://opensource.org/licenses/gpl-3.0.html GNU General Public License,version 3 (GPL-3.0)
* @author Magedelight <info@magedelight.com>
*/

namespace Ironedge\CustomDiscount\Model\Total\Invoice;

class CustomDiscount extends \Magento\Sales\Model\Order\Invoice\Total\AbstractTotal
{
    /**
     * Collect Giftwrapper Initial amounts for the invoice.
     *
     * @param \Magento\Sales\Model\Order\Invoice $invoice
     *
     * @return $this
     * @SuppressWarnings(PHPMagedelight.CyclomaticComplexity)
     * @SuppressWarnings(PHPMagedelight.NPathComplexity)
     * @SuppressWarnings(PHPMagedelight.ExcessiveMethodLength)
     */
    public function collect(\Magento\Sales\Model\Order\Invoice $invoice)
    {
        $store = $invoice->getStore();
        $order = $invoice->getOrder();

        $customDiscount = $order->getCustomDiscount();
        
        $totalInitialAmount = 0;
        $baseTotalInitialAmount = 0;

        $totalInitialAmount = $customDiscount;
        $baseTotalInitialAmount = $customDiscount;

        $invoice->setTaxAmount($invoice->getTaxAmount());
        $invoice->setBaseTaxAmount($invoice->getBaseTaxAmount());

        $invoice->setGrandTotal($order->getGrandTotal());
        $invoice->setBaseGrandTotal($order->getBaseGrandTotal());

        return $this;
    }
}
