<?php
/**
* Magedelight
* Copyright (C) 2016 Magedelight <info@magedelight.com>
*
* @category Magedelight
* @package Magedelight_CustomDiscount
* @copyright Copyright (c) 2016 Mage Delight (http://www.magedelight.com/)
* @license http://opensource.org/licenses/gpl-3.0.html GNU General Public License,version 3 (GPL-3.0)
* @author Magedelight <info@magedelight.com>
*/
namespace Ironedge\CustomDiscount\Model\Total\Quote;


class CustomDiscount extends \Magento\Quote\Model\Quote\Address\Total\AbstractTotal
{
   /**
     * Collect grand total address amount
     *
     * @param \Magento\Quote\Model\Quote $quote
     * @param \Magento\Quote\Api\Data\ShippingAssignmentInterface $shippingAssignment
     * @param \Magento\Quote\Model\Quote\Address\Total $total
     * @return $this
     */
    protected $quoteValidator = null; 
	
	/**
    * @var \Magento\Framework\Pricing\PriceCurrencyInterface
    */
    protected $_priceCurrency;
   
    /**
    * Params
    *
    * @var Magento\Framework\App\Request\Http $request
    */
    protected $request;

    /**
    * adminCheckoutSession
    * @var Magento\Backend\Model\Session\Quote $adminCheckoutSession
    */
    protected $adminCheckoutSession;

    /**
    * @param Magento\Quote\Model\QuoteValidator $quoteValidator
    * @param Magento\Framework\App\Request\Http $request
    * @param Magento\Backend\Model\Session\Quote $adminCheckoutSession
    * @param Magento\Checkout\Model\Cart $cart
    */
    public function __construct(
        \Magento\Quote\Model\QuoteValidator $quoteValidator,
        \Magento\Framework\App\Request\Http $request,
        \Magento\Backend\Model\Session\Quote $adminCheckoutSession,
		\Magento\Framework\Pricing\PriceCurrencyInterface $priceCurrency,
        \Magento\Checkout\Model\Cart $cart
    )
    {
        $this->quoteValidator = $quoteValidator;
        $this->request = $request;
		$this->_priceCurrency = $priceCurrency;
        $this->adminCheckoutSession = $adminCheckoutSession;
        $this->cart = $cart;
    }

    /**
     * @param Magento\Quote\Model\Quote\Address\Total $total
     * @param Magento\Quote\Api\Data\ShippingAssignmentInterface $shippingAssignment
     * @param Magento\Quote\Model\Quote $quote
     * @return array
     */
    public function collect(
        \Magento\Quote\Model\Quote $quote,
        \Magento\Quote\Api\Data\ShippingAssignmentInterface $shippingAssignment,
        \Magento\Quote\Model\Quote\Address\Total $total
    ) {
        $items = $shippingAssignment->getItems();
        if (!count($items)) {
            return $this;
        }
        parent::collect($quote, $shippingAssignment, $total);
		
		$quoteSubtotal = "";
        $exist_amount = 0; 
        $customdiscount = $this->getCustomDiscountTotal($quote);
        $baseDiscount = $customdiscount + $exist_amount;

        $discount =  $this->_priceCurrency->convert($baseDiscount);
		$total->addTotalAmount('customdiscount', -$discount);
		$total->addBaseTotalAmount('customdiscount', -$baseDiscount);
		$total->setBaseGrandTotal($total->getBaseGrandTotal() - $baseDiscount);
		$quote->setCustomDiscount($discount);
		
		if(isset($_POST['order']['custom']['discount']) && isset($_POST['order']['discount']['type'])){
			$discountValue = $_POST['order']['custom']['discount'];
			$discountType = $_POST['order']['discount']['type']; 
			$quote->setDiscountValue($discountValue);
			$quote->setDiscountType($discountType);
		}

        return $this;
    } 

    /**
    * Set Order Total Values
    * @return null
    */
    protected function clearValues(Address\Total $total)
    {
        $total->setTotalAmount('subtotal', 0);
        $total->setBaseTotalAmount('subtotal', 0);
        $total->setTotalAmount('tax', 0);
        $total->setBaseTotalAmount('tax', 0);
        $total->setTotalAmount('discount_tax_compensation', 0);
        $total->setBaseTotalAmount('discount_tax_compensation', 0);
        $total->setTotalAmount('shipping_discount_tax_compensation', 0);
        $total->setBaseTotalAmount('shipping_discount_tax_compensation', 0);
        $total->setSubtotalInclTax(0);
        $total->setBaseSubtotalInclTax(0);
    }

    /**
     * @param \Magento\Quote\Model\Session $quote
     * @param CustomDiscount Price
     * @return $customdiscounttotal
     */
    public function getCustomDiscountTotal($quote)
	{
        /*Custom Discount calculation*/
		$finalDiscount = 0;
		$subtotal = $quote->getSubtotal();
        if(isset($_POST['order']['custom']['discount']) && isset($_POST['order']['discount']['type'])){
			$discountValue = $_POST['order']['custom']['discount'];
			$discountType = $_POST['order']['discount']['type']; 
			if($discountType == 'percent'){
				$finalDiscount = $discountValue/100*$subtotal;
			}else{
				$finalDiscount = $discountValue;
			}
		}else{
            $finalDiscount = $quote->getCustomDiscount();
        }
		/*Custom Discount calculation ends here */
        
        return $finalDiscount;
    }
    /**
     * @param \Magento\Quote\Model\Quote $quote
     * @param Address\Total $total
     * @return array|null
     */
    /**
     * Assign subtotal amount and label to address object
     *
     * @param \Magento\Quote\Model\Quote $quote
     * @param Address\Total $total
     * @return array
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function fetch(\Magento\Quote\Model\Quote $quote, \Magento\Quote\Model\Quote\Address\Total $total)
    {
        
        return [
            'code' => 'customdiscount',
            'title' => 'Custom Discount',
            'value' => $this->getCustomDiscountTotal($quote)
        ];
        
    }

    /**
     * Get Subtotal label
     *
     * @return \Magento\Framework\Phrase
     */
    public function getLabel()
    {
        return __('Custom Discount');
    }
}