<?php

namespace Ironedge\CustomDiscount\Model\Sales\Pdf;

class CustomDiscount extends \Magento\Sales\Model\Order\Pdf\Total\DefaultTotal
{
    /**
     * @param \Magento\Tax\Helper\Data                                           $taxHelper
     * @param \Magento\Tax\Model\Calculation                                     $taxCalculation
     * @param \Magento\Tax\Model\ResourceModel\Sales\Order\Tax\CollectionFactory $ordersFactory
     * @param array                                                              $data
     */
    public function __construct(
        \Magento\Tax\Helper\Data $taxHelper, 
        \Magento\Tax\Model\Calculation $taxCalculation, 
        \Magento\Tax\Model\ResourceModel\Sales\Order\Tax\CollectionFactory $ordersFactory, 
        array $data = []
    ) {
		parent::__construct($taxHelper, $taxCalculation, $ordersFactory, $data);
    }

    /**
     * @return array
     */
    public function getTotalsForDisplay()
    {
        $customDiscount = $this->getOrder()->getCustomDiscount();
        
        if (empty($customDiscount) || $customDiscount == 0) {
            return [];
        }
        $amount = $this->getOrder()->formatPriceTxt($customDiscount);
		
		//$amount = $this->getOrder()->formatPriceTxt($this->getAmount());
        if ($this->getAmountPrefix()) {
            $amount = $this->getAmountPrefix().$amount;
        }

        $title = __($this->getTitle());
        if ($this->getTitleSourceField()) {
            $label = $title.' ('.$this->getTitleDescription().'):';
        } else {
            $label = $title.':';
        }

        $fontSize = $this->getFontSize() ? $this->getFontSize() : 7;
        $total = ['amount' => $amount, 'label' => $label, 'font_size' => $fontSize];

        return [$total];
    }
}
