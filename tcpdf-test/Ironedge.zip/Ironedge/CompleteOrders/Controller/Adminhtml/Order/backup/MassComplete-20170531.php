<?php
/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Ironedge\CompleteOrders\Controller\Adminhtml\Order;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
use Magento\Backend\App\Action\Context;
use Magento\Ui\Component\MassAction\Filter;
use Magento\Sales\Model\ResourceModel\Order\CollectionFactory;
use \Magento\Sales\Api\Data\OrderInterface;

class MassComplete extends \Magento\Sales\Controller\Adminhtml\Order\AbstractMassAction
{
    /**
     * @param Context $context
     * @param Filter $filter
     * @param CollectionFactory $collectionFactory
     */
    public function __construct(Context $context, Filter $filter, OrderInterface $order, CollectionFactory $collectionFactory)
    {
        parent::__construct($context, $filter);
        $this->collectionFactory = $collectionFactory;
        $this->order = $order;
    }

    /**
     * Cancel selected orders
     *
     * @param AbstractCollection $collection
     * @return \Magento\Backend\Model\View\Result\Redirect
     */
    protected function massAction(AbstractCollection $collection)
    {
        $countCompleteOrder = 0;
        foreach ($collection->getItems() as $order) {
            $order = $this->order->loadByIncrementId($order->getIncrementId());
            $order->setStatus('complete');
            $order->setState('complete');
            $order->save();
            $countCompleteOrder++;
        }
        $countNonCompleteOrder = $collection->count() - $countCompleteOrder;

        if ($countNonCompleteOrder && $countCompleteOrder) {
            $this->messageManager->addError(__('%1 order(s) cannot be completed.', $countNonCompleteOrder));
        } elseif ($countNonCompleteOrder) {
            $this->messageManager->addError(__('You cannot complete the order(s).'));
        }

        if ($countCompleteOrder) {
            $this->messageManager->addSuccess(__('We completed %1 order(s).', $countCompleteOrder));
        }
        $resultRedirect = $this->resultRedirectFactory->create();
        $resultRedirect->setPath($this->getComponentRefererUrl());
        return $resultRedirect;
    }
}
