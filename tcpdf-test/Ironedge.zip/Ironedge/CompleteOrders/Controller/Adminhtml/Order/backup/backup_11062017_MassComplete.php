<?php
/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Ironedge\CompleteOrders\Controller\Adminhtml\Order;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
use Magento\Backend\App\Action\Context;
use Magento\Ui\Component\MassAction\Filter;
use Magento\Sales\Model\ResourceModel\Order\CollectionFactory;
use Magento\Sales\Api\Data\OrderInterface;
use Magento\Sales\Model\Order\ShipmentFactory;
use Magento\Sales\Model\Order\Invoice;
use Magento\Sales\Model\Service\InvoiceService;
use Magento\Shipping\Controller\Adminhtml\Order\ShipmentLoader;

class MassComplete extends \Magento\Sales\Controller\Adminhtml\Order\AbstractMassAction
{
    /**
     * @param Context $context
     * @param Filter $filter
     * @param CollectionFactory $collectionFactory
     */
	 
	private $invoiceService;
	protected $shipmentFactory;
	protected $shipmentLoader;
	
    public function __construct(Context $context, Filter $filter, OrderInterface $order, CollectionFactory $collectionFactory, ShipmentFactory $shipmentFactory, InvoiceService $invoiceService, ShipmentLoader $shipmentLoader)
    {
        parent::__construct($context, $filter);
        $this->collectionFactory = $collectionFactory;
        $this->order = $order;
		$this->shipmentFactory = $shipmentFactory;
        $this->invoiceService = $invoiceService;
        $this->shipmentLoader = $shipmentLoader;
    }

    /**
     * Cancel selected orders
     *
     * @param AbstractCollection $collection
     * @return \Magento\Backend\Model\View\Result\Redirect
     */
    protected function massAction(AbstractCollection $collection)
    {
        $countCompleteOrder = 0;
        foreach ($collection->getItems() as $order) {
            $order = $this->order->loadByIncrementId($order->getIncrementId());            
			/*generate invoice and shipment start*/
			$invoiceArray = array();
			$invoiceArray['invoice']['do_shipment'] = 1; 
			$invoiceArray['invoice']['comment_text'] = "";
			foreach ($order->getAllVisibleItems() as $item) {
				$invoiceArray['invoice']['items'][$item->getId()] = (string)(int)$item->getQtyOrdered(); 
			}
			$order_id = $order->getId();
			if($order->getState()!='closed' && $order->getState()!='complete' && $order->getState()!='canceled'){
				$this->createInvoice($invoiceArray,$order_id);
				/*$order->setStatus('complete');
	            $order->setState('complete');
	            $order->save();*/
				$countCompleteOrder++;
			}			
			/*generate invoice and shipment end*/
			
            
            
        }
        $countNonCompleteOrder = $collection->count() - $countCompleteOrder;

        if ($countNonCompleteOrder && $countCompleteOrder) {
            $this->messageManager->addError(__('%1 order(s) cannot be completed.', $countNonCompleteOrder));
        } elseif ($countNonCompleteOrder) {
            $this->messageManager->addError(__('You cannot complete the order(s).'));
        }

        if ($countCompleteOrder) {
            $this->messageManager->addSuccess(__('We completed %1 order(s).', $countCompleteOrder));
        }
        $resultRedirect = $this->resultRedirectFactory->create();
        $resultRedirect->setPath($this->getComponentRefererUrl());
        return $resultRedirect;
    }
    protected function _prepareShipment($invoice,$data)
    {
        $invoiceData = $data['invoice'];

        $shipment = $this->shipmentFactory->create(
            $invoice->getOrder(),
            isset($invoiceData['items']) ? $invoiceData['items'] : [],
            ''
        );
        return $shipment->register();
    }
    public function createInvoice($data,$orderId)
    {
    	$invoiceData = $data['invoice'];
        $invoiceItems = isset($invoiceData['items']) ? $invoiceData['items'] : [];
      
        /** @var \Magento\Sales\Model\Order $order */
        $order = $this->_objectManager->create('Magento\Sales\Model\Order')->load($orderId);
        
        $_invoices = $order->getInvoiceCollection();
	    $invoiceId = FALSE;
		if($_invoices){
			foreach($_invoices as $invoice){
				$invoiceId = $invoice->getId();
			}
		}
		$_shipment_cols = $order->getShipmentsCollection();
	    $shipmentId = FALSE;
		if($_shipment_cols){
			foreach($_shipment_cols as $_shipment_col){
				$shipmentId = $_shipment_col->getId();
			}
		}
        if (!$invoiceId) {
          	$invoice = $this->invoiceService->prepareInvoice($order, $invoiceItems);  
          	/*if (!empty($data['capture_case'])) {
                $invoice->setRequestedCaptureCase($data['capture_case']);
            }*/
            $invoice->register();
            $invoice->getOrder()->setIsInProcess(true);
            
            $transactionSave = $this->_objectManager->create(
            'Magento\Framework\DB\Transaction'
	            )->addObject(
	                $invoice
	            )->addObject(
	                $invoice->getOrder()
	            );
	        if (!$shipmentId) {
		        $shipment = $this->_prepareShipment($invoice,$data);
		        if ($shipment) {
		            $transactionSave->addObject($shipment);
		        }
	        }
	        $transactionSave->save();
        }else{
			if (!$shipmentId) {
	          	$this->createShipment($invoiceData, $orderId);  
	        }
		}
        
        
    }
    public function createShipment($invoiceData,$orderId)
    {
        $data = $invoiceData;

        $this->shipmentLoader->setOrderId($orderId);
        $this->shipmentLoader->setShipmentId(NULL);
        $this->shipmentLoader->setShipment($data);
        $this->shipmentLoader->setTracking(NULL);
        $shipment = $this->shipmentLoader->load();        
        $shipment->register();
        $this->_saveShipment($shipment);
    }
    protected function _saveShipment($shipment)
    {
        $shipment->getOrder()->setIsInProcess(true);
        $transaction = $this->_objectManager->create(
            'Magento\Framework\DB\Transaction'
        );
        $transaction->addObject(
            $shipment
        )->addObject(
            $shipment->getOrder()
        )->save();

        return $this;
    }
}
