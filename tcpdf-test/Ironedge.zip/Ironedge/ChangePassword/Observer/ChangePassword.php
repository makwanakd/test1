<?php

/**
 * Magedelight
 * Copyright (C) 2016 Magedelight <info@magedelight.com>
 *
 * @category Magedelight
 * @package Magedelight_Giftwrapper
 * @copyright Copyright (c) 2016 Mage Delight (http://www.magedelight.com/)
 * @license http://opensource.org/licenses/gpl-3.0.html GNU General Public License,version 3 (GPL-3.0)
 * @author Magedelight <info@magedelight.com>
 */

namespace Ironedge\ChangePassword\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Store\Model\StoreManagerInterface;

class ChangePassword implements ObserverInterface 
{
    /**
     * @var \Magento\Framework\App\Request\Http
     */
    protected $_request;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $_scopeConfig;

    /**
     * @var \Magento\Directory\Model\Currency
     */
    protected $_currency;

    /**
     * @param \Magento\Framework\App\Request\Http                $request
     * @param StoreManagerInterface                              $storeManager
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Magento\Directory\Model\Currency                  $currency
     */
    public function __construct(
    \Magento\Framework\App\Request\Http $request, 
    \Magento\Framework\App\Filesystem\DirectoryList $directorylist,
    \Magento\Customer\Api\CustomerRepositoryInterface $customerRepositoryInterface
    ) {
        $this->request = $request;
        $this->directorylist = $directorylist;
        $this->_customerRepositoryInterface = $customerRepositoryInterface;
    }

    /**
     * @param \Magento\Framework\Event\Observer $observer
     */
    public function execute(\Magento\Framework\Event\Observer $observer) 
    {
        $post = $this->request->getParams();
        if(!empty($post['password']))
        {
            $root = $this->directorylist->getRoot();
            $customer = $observer->getEvent()->getCustomer();
            $logFile = $root.'/var/changepsword.log';

            system('/usr/bin/php70 '.$root.'/bin/magento customer:changepassword --customer-id='.$customer->getId().' --customer-password='.$post['password'].' >> '.$logFile); 
        }
    }

}
