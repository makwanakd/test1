<?php
namespace Ironedge\AcartMonitor\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\DB\Adapter\AdapterInterface;

class InstallSchema implements InstallSchemaInterface {

    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context) {
        $installer = $setup;

        $installer->startSetup();

        $installer->getConnection()->addColumn(
            $installer->getTable('mst_email_queue'), 'is_checked_out', [
                'type' => \Magento\Framework\DB\Ddl\Table::TYPE_SMALLINT,
                'length' => 2,
                'after' => 'args_serialized',
                'nullable' => false,
                'comment' => 'Was Cart Restored',
            ]
        );

        $installer->getConnection()->addColumn(
            $installer->getTable('mst_email_queue'), 'quote_id', [
                'type' => \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                'length' =>11,
                'after' => 'is_checked_out',
                'nullable' => false,
                'comment' => 'Quote Id',
            ]
        );

        $installer->getConnection()->addColumn(
            $installer->getTable('mst_email_queue'), 'converted_to_order', [
                'type' => \Magento\Framework\DB\Ddl\Table::TYPE_SMALLINT,
                'length' => 2,
                'after' => 'quote_id',
                'nullable' => false,
                'comment' => 'Was it successful',
            ]
        );

        $installer->endSetup();
    }

}
