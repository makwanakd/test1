<?php
/**
 * Mirasvit
 *
 * This source file is subject to the Mirasvit Software License, which is available at https://mirasvit.com/license/.
 * Do not edit or add to this file if you wish to upgrade the to newer versions in the future.
 * If you wish to customize this module for your needs.
 * Please refer to http://www.magentocommerce.com for more information.
 *
 * @category  Mirasvit
 * @package   mirasvit/module-email
 * @version   1.0.29
 * @copyright Copyright (C) 2017 Mirasvit (https://mirasvit.com/)
 */



namespace Ironedge\AcartMonitor\Helper\Mirasvit;

/**
 * @SuppressWarnings(PHPMD)
 * @codingStandardsIgnoreFile
 */
class Frontend extends \Mirasvit\Email\Helper\Frontend
{
    public function restoreCartByQueueHash($hash)
    {
        $queue = $this->getQueue($hash);

        if ($queue) {
            $orderId       = $queue->getArg('order_id');
            $quoteId       = $queue->getArg('quote_id');
            $customerEmail = $queue->getArg('customer_email');
            $customerId    = $queue->getArg('customer_id');

            //set custom values to monitor abandoned cart email starts here
            $queue->setQuoteId($quoteId);
            $queue->setIsCheckedOut(1);
            $queue->save(); 

            //Cart monitor code ends here   

            if ($quoteId) {
                $quote = $this->quoteFactory->create()->setSharedStoreIds(array_keys($this->storeManager->getStores()))
                    ->load($quoteId);

                $quote->setIsActive(true)->save();

                $this->session->replaceQuote($quote);

                return true;
            } elseif ($orderId) {
                $order = $this->orderFactory->create()->load($orderId);

                $cart = $this->cart;
                $cart->truncate();

                $items = $order->getItemsCollection();
                foreach ($items as $item) {
                    try {
                        $cart->addOrderItem($item);
                    } catch (\Exception $e) {
                        $this->messageManager->addExceptionMessage($e, 'Cannot add the item to shopping cart.');
                    }
                }

                $cart->saveQuote();
                $cart->save();

                $this->session->replaceQuote($cart->getQuote());

                return true;
            } elseif (!$customerId && $customerEmail) { // guest
                $quote = $this->quoteHelper->getCartByCapturedEmail($customerEmail);

                if ($quote->getId()) {
                    $this->cart->truncate();

                    $quote->setIsActive(true)->save();

                    $this->session->replaceQuote($quote);
                    $this->cart->setQuote($this->session->getQuote())
                        ->save();

                    return true;
                }
            }
        }

        return false;
    }
}
