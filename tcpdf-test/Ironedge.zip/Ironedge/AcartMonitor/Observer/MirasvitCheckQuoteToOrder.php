<?php
namespace Ironedge\AcartMonitor\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;

class MirasvitCheckQuoteToOrder implements ObserverInterface
{
    
    protected $_objectManager;

    public function __construct(
        \Mirasvit\Email\Model\QueueFactory $queueFactory,
        \Magento\Framework\ObjectManagerInterface $objectmanager
    ) 
    {
        $this->_objectManager = $objectmanager;
        $this->queueFactory    = $queueFactory;
    }
    /**
     * Handler for 'sales_order_save_after' event.
     *
     * @param Observer $observer
     * @return void
     */
    public function execute(Observer $observer)
    {
        $orderIds = $observer->getEvent()->getOrderIds(); 
        //echo "<pre>"; print_r($orderIds); echo $orderIds[0]; die;

        $order = $this->_objectManager->create('Magento\Sales\Model\Order')->load($orderIds[0]);

        $queueCollection = $this->queueFactory->create()->getCollection()
                ->addFieldToFilter('quote_id', array('eq' => $order->getQuoteId()))
                ->load();
        //echo $order->getQuoteId(); echo "<pre>"; print_r($queueCollection->getData()); die;
        if(sizeof($queueCollection->getData()) > 0)
        {
            foreach($queueCollection as $queue)
            {
                $queueobj = $this->_objectManager->create('Mirasvit\Email\Model\Queue')->load($queue->getQueueId());
                $queueobj->setData('converted_to_order',1);
                $queueobj->save();
            }
        }
    }
}
