<?php

namespace Ironedge\Customization\Observer;

use Magento\Framework\Event\ObserverInterface;
use Psr\Log\LoggerInterface;

class CheckProductOptionsAvailability implements ObserverInterface
{
 
 	protected $stockRegistry;
  	/**
	* @var Google reCaptcha Options
	*/
	
	public function __construct(
        \Magento\Framework\App\Request\Http $request,
		\Magento\Framework\ObjectManagerInterface $objectmanager,
		\Magento\Catalog\Model\ProductFactory $productFactory,
		\Magento\CatalogInventory\Api\StockRegistryInterface $stockRegistry
    ) {
       $this->request = $request;
	   $this->_objectManager = $objectmanager;
	   $this->_productFactory = $productFactory;
	   $this->stockRegistry = $stockRegistry;
    }
	
	/**
     * Add price index data for catalog product collection
     * only for front end
     *
     * @param \Magento\Framework\Event\Observer $observer
     * @return $this
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
		$action = $this->request->getFullActionName();
		if($action == 'catalog_product_view')
		{
			$collection = $observer->getEvent()->getCollection();
			//echo "<pre>"; print_r($collection->getData()); die;
			foreach($collection as $item)
			{
				if(null !== $item->getData('parent_product_id') && 
					!empty($item->getData('parent_product_id')) && 
					null !== $item->getData('is_default') && 
					$item->getData('is_default') == 1
					){
						if($item->getIsSalable() == 1)
						{
							continue;
						}else{
							$product = $this->_productloader->create()->load($item->getData('parent_product_id'));
							$stockItem = $this->stockRegistry->getStockItem($item->getData('parent_product_id'));
							$stockItem->setData('is_in_stock',0);
							$stockItem->save();
							$product->save();
						}
					}
			}
        }
		return $this;
    }
}
