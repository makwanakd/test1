<?php

namespace Ironedge\Customization\Observer;

use Magento\Framework\Event\ObserverInterface;
use Psr\Log\LoggerInterface;
use Magento\Framework\App\Filesystem\DirectoryList;

class CheckBundleIsSalable implements ObserverInterface
{
 
 	/**
     * @var Magento\CatalogInventory\Api\StockStateInterface 
     */
    protected $_stockStateInterface;
 
    /**
     * @var Magento\CatalogInventory\Api\StockRegistryInterface 
     */
    protected $_stockRegistry;
 
    /**
    * @param Magento\Framework\App\Helper\Context $context
    * @param Magento\Catalog\Model\Product $product
    * @param Magento\CatalogInventory\Api\StockStateInterface $stockStateInterface,
    * @param Magento\CatalogInventory\Api\StockRegistryInterface $stockRegistry
    */
    public function __construct(
        \Magento\CatalogInventory\Api\StockStateInterface $stockStateInterface,
        \Magento\CatalogInventory\Api\StockRegistryInterface $stockRegistry 
    ) {
        $this->_stockStateInterface = $stockStateInterface;
        $this->_stockRegistry = $stockRegistry;
    }
  	
	/**
	* Save Form Data
	*
	* @return array
	*/
	public function execute(\Magento\Framework\Event\Observer $observer)
	{
		$_product = $observer->getEvent()->getProduct();
		$saleable = true;
		if(null !== $_product->getData('amasty_native_is_salable'))
		{
			$saleable = $_product->getData('amasty_native_is_salable');
		}
		if($_product->getData('is_salable') == 0 || strpos($_product->getData('name'), 'Out of Stock') !== false || !$saleable)
		{
			$stockItem=$this->_stockRegistry->getStockItem($_product->getData('parent_product_id')); // load stock of that product
	        $stockItem->setData('is_in_stock',0);
			$stockItem->setData('qty',0); //set updated quantity 
	        $stockItem->setData('manage_stock',1);
    	    $stockItem->setData('use_config_notify_stock_qty',1);
			$stockItem->save();
		}
	}
}