<?php

namespace Ironedge\Customization\Observer;

use Magento\Framework\Event\ObserverInterface;
use Psr\Log\LoggerInterface;

class ReviewsCaptcha implements ObserverInterface
{
 
  	/**
	* @var Google reCaptcha Options
	*/
	private static $_siteVerifyUrl = "https://www.google.com/recaptcha/api/siteverify?";
	private $_secret;
	private static $_version = "php_1.0";
	
	public function __construct(
        \Magento\Framework\App\Request\Http $request,
		\Magento\Framework\Controller\ResultFactory $resultFactory,
		\Magento\Framework\App\Response\RedirectInterface $redirect,
		\Magento\Framework\App\ResponseFactory $responseFactory,
        \Magento\Framework\UrlInterface $url,
		\Magento\Framework\Message\ManagerInterface $messageManager
    ) {
       $this->request = $request;
	   $this->resultFactory = $resultFactory;
	   $this->_responseFactory = $responseFactory;
       $this->_url = $url;
	   $this->redirect = $redirect;
	   $this->_messageManager = $messageManager;
    }
	
	/**
	* Save Form Data
	*
	* @return array
	*/
	public function execute(\Magento\Framework\Event\Observer $observer)
	{
		$data = $this->request->getPost();
		$captcha = $data['g-recaptcha-response'];
		$secret = "6LeX6h8UAAAAAJbUypHtApEj4pBHJkZK3AjuWoRR"; //Replace with your secret key
		$response = null;
		$path = self::$_siteVerifyUrl;
		$dataC = array (
		'secret' => $secret,
		'remoteip' => $_SERVER["REMOTE_ADDR"],
		'v' => self::$_version,
		'response' => $captcha
		);
		$req = "";
		foreach ($dataC as $key => $value) {
			 $req .= $key . '=' . urlencode(stripslashes($value)) . '&';
		}
		// Cut the last '&'
		$req = substr($req, 0, strlen($req)-1);
		$response = file_get_contents($path . $req);
		$answers = json_decode($response, true);
		if(trim($answers ['success']) == true) {
			return true;
		}else{
			$this->_messageManager->addError('Please verify if you are not a robot.');
			//$resultRedirect = $this->resultFactory->create(\Magento\Framework\Controller\ResultFactory::TYPE_REDIRECT);
			$this->_responseFactory->create()->setRedirect($this->redirect->getRefererUrl())->sendResponse();
			exit();
			
		}
	}
}