<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2016 Amasty (https://www.amasty.com)
 * @package Amasty_ProductAttachment
 */

namespace Ironedge\Customization\Block\Catalog\Product;

/**
 * Class Attachment
 *
 * custom paste to template
 * <?php echo $block->getLayout()->createBlock('Amasty\ProductAttachment\Block\Catalog\Product\Attachment', '', ['data'=>['custom_mode'=> true, 'skip_head'=>true]])->toHtml(); ?>
 *
 * @package Amasty\ProductAttachment\Block\Catalog\Product
 */
class Articles extends \Magento\Framework\View\Element\Template
{
    const TABS_BLOCK_NAME = 'product.info.details';

    const TABS_GROUP_NAME = 'detailed_info';

    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $customerSession;

    /**
     * Core registry
     *
     * @var \Magento\Framework\Registry
     */
    protected $coreRegistry;

    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Customer\Model\Session $session,
        \Magento\Framework\Registry $coreRegistry,
        array $data = []
    ) {
        parent::__construct($context, $data);

        $this->customerSession = $session;
        $this->coreRegistry = $coreRegistry;

    }

    protected function _construct()
    {
        parent::_construct();
        $this->setTemplate('Ironedge_Customization::product/articles.phtml');
    }

    protected function _prepareLayout()
    {
       parent::_prepareLayout();

       $this->addToTabs();
        
       $this->setTitle('Articles');
    }

    public function addToTabs()
    {
        $this->addToBlock(self::TABS_BLOCK_NAME);
        $this->getLayout()->addToParentGroup($this->getNameInLayout(), self::TABS_GROUP_NAME);
    }

    protected function addToBlock($blockName)
    {
        if ($this->getLayout()->isBlock($blockName) || $this->getLayout()->isContainer($blockName) ) {
            $selfBlockName = $this->getNameInLayout();

            $this->getLayout()->setChild(
                $blockName, $selfBlockName, 'articles_content'
            );
        }
    }

    /**
     * Get product that is being edited
     *
     * @return \Magento\Catalog\Model\Product
     */
    public function getProduct()
    {
        return $this->coreRegistry->registry('product');
    }

    public function toHtml()
    {
        return $this->isAllowed() ? parent::toHtml() : '';
    }
	
	public function getArticleContent()
	{
		return $this->getProduct()->getArticleslink();
	}

    public function isAllowed()
    {
        return !empty($this->getArticleContent()); /*$this->configHelper->getDisplayBlock()
        && $this->getCountAttachmentFiles() > 0
        ;*/
    }

    public function getBlockLabel()
    {
        return 'Articles';
    }

}
