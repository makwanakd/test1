<?php

namespace Ironedge\Customization\Block\Newsletter;

/**
 * Class Attachment
 *
 * custom paste to template
 * <?php echo $block->getLayout()->createBlock('Amasty\ProductAttachment\Block\Catalog\Product\Attachment', '', ['data'=>['custom_mode'=> true, 'skip_head'=>true]])->toHtml(); ?>
 *
 * @package Amasty\ProductAttachment\Block\Catalog\Product
 */
class Subscribe extends \Magento\Newsletter\Block\Subscribe
{
    public function getFormActionUrl()
    {
        return "https://ironedge.us7.list-manage.com/subscribe/post?u=9a2223740f2166e5cbc1a7cfd&amp;id=ca9518bfa6";//$this->getUrl('newsletter/subscriber/new', ['_secure' => true]);
    }
}
