<?php
namespace Ironedge\Customization\Setup;

use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

/**
 * @codeCoverageIgnore
 */
class UpgradeSchema implements UpgradeSchemaInterface {

    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context) {
        $installer = $setup;

        $installer->startSetup();
        if (version_compare($context->getVersion(), '1.0.1') < 0) {   
			$installer->getConnection()->addColumn(
			$installer->getTable('quote'),
				'gift_card_value',
				[
					'type' => \Magento\Framework\DB\Ddl\Table::TYPE_DECIMAL,
					'length' => '12,4',
					'unsigned' => true,
					'nullable' => true,
					'default' => '0.0000',
					'comment' => 'Amasty Gift card Value'
				]
			);
	
			$installer->getConnection()->addColumn(
			$installer->getTable('sales_order'),
				'gift_card_value',
				[
					'type' => \Magento\Framework\DB\Ddl\Table::TYPE_DECIMAL,
					'length' => '12,4',
					'unsigned' => true,
					'nullable' => true,
					'default' => '0.0000',
					'comment' => 'Amasty Gift card Value'
				]
			);
		}
		
		$installer->endSetup();
    }

}
