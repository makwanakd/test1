var config = {
    map: {
        '*': {
            rsslider : "Ironedge_Customization/js/jquery.royalslider.min",
            ironedge_home : "Ironedge_Customization/js/ironedge_home",
            viewportchecker : "Ironedge_Customization/js/viewportchecker"
        },
        shim: {
	        'banner.rsslider': {
	            'deps': ['jquery']
	        },
	        'banner.ironedge_home': {
	            'deps': ['jquery']
	        },
	        'banner.viewportchecker': {
	            'deps': ['jquery']
	        }
	    }
    }
};