require(["jquery"], function($){
  jQuery(function($) {
    'use strict';
    var windowheight    = $(window).height();
    var windowWidth     = $(window).width();




    var heightset;
      $(window).resize(function(){
        windowheight    = $(window).height();
        windowWidth     = $(window).width();
      });


    // new touch device 
      /*$('.post').addClass("zxu_mhidden").viewportChecker({
        classToAdd: 'zxu_mvisable animated fadeInDown',
        offset: 100,
        removeClassAfterAnimation:true,
        classToAddForFullView: '',
        classToRemove: 'zxu_mhidden'
      });*/

  });

  
  if ($('.zxu_scrol_by_hash').length > 0) {
    $('.zxu_scrol_by_hash a[href*=#]:not([href=#])').click(function(ev) {
      if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {
        var target = $(this.hash);
        target = target.length ? target : $('[id=' + this.hash.slice(1) +']');
        var targetTop = target.offset().top,
            header = $('.header-wrapper'),
            headerHeight = header.height(),
            trNav = $('.zxu_cmp_nav'),
            trNavHeight = trNav.outerHeight(),
            windowWidth = $(window).width();
          if (windowWidth > 767) {
              if (header.length > 0) {
                targetTop = targetTop - 175;
              }else{
                targetTop = targetTop;
              }
          }else{
            if (header.length > 0) {
                targetTop = targetTop - 175;
              }else{
                targetTop = targetTop;
              }
          }
        if (target.length) {
          $('html,body').animate({
            scrollTop: targetTop
          }, 1000,"easeInOutQuint");
          return false;
        }
      }
      ev.defaultPrevented();
    });
  }

  


        
        if($("#zxu_home_slider").length > 0){
          jQuery.rsCSS3Easing.easeOutExpo = 'cubic-bezier(0.190, 1.000, 0.220, 1.000)';
          var homeslider = $('#zxu_home_slider').royalSlider({
          
              arrowsNav: false,
              loop: true,
              keyboardNavEnabled: false,
              controlsInside: true,
              imageScaleMode: 'fill',
              arrowsNavAutoHide: true,
              autoScaleSlider: false, 
              controlNavigation: 'bullets',
              thumbsFitInViewport: false,
              imageScalePadding:0,
              slidesSpacing:0,
              sliderDrag:true,
              navigateByClick: false,
              startSlideId: 0,
              autoPlay: {
                  enabled: true,
                  pauseOnHover: false,
                  delay:5000
              },
              transitionType:'move',
              globalCaption: false,
             
              imgWidth: 1920,
              imgHeight: 1050,
              blockLoop: true,
          }).data('royalSlider');


          homeslider.ev.on('rsSlideClick', function(event, originalEvent) {
            //console.log(event)
            var wh = $(window).width()/2;
            var clickPosition = originalEvent.screenX;
            if(originalEvent.toElement.nodeName != 'A'){
              if(clickPosition > wh){
                homeslider.next();
              }else{
                homeslider.prev();
              }
            }
          });

          var videoSliderLength = $("#videoSlide").length;
          var countVideo;
          var cloneVideoSliderContent = $("#videoSlide");
          var mp4Link;
          var webLinks;
          if(videoSliderLength > 0){
            countVideo = true;
              mp4Link = cloneVideoSliderContent.find('source:first-child').attr('src');
              webLinks = cloneVideoSliderContent.find('source:last-child').attr('src');
          }else{
             countVideo = false;
          }
         /* slider width height  */
          var resize = function() {
            var h = $(window).height();
            var w = $(window).width();
            if($('.header-wrapper').length > 0){
                h = $(window).height() - $('.header-wrapper').outerHeight();
                if($('.breadcrumb').length >0){
                  h = h-$('.breadcrumb').outerHeight();
                }
            }else{
               h = $(window).height();
            }
            $("#zxu_home_slider").css({
                width: w,
                height:h
            });
            $('#zxu_home_slider').royalSlider('updateSliderSize', true);
            var videoSliderLength = $("#videoSlide").length;
            var videoSlides;
            
            if(countVideo == true){              
              var videoSlide = '<div class="rsContent"><div class="zxu_infoBlock" id="videoSlide" style="background-image: none; background:#000;"><div class="zxu_container_video"><a href="javascript:void(0)" type="button" class="playpush"></a><video width="100%" height="100%" loop> <source src="'+mp4Link+'" type="video/mp4"><source src="'+webLinks+'" type="video/webm"> Your browser does not support HTML5 video.</video> </div></div></div>';
            var videoSlideCount = $('#zxu_home_slider').find('#videoSlide').length;
            if(w > 1030){
              var videoSlideCount = $('#zxu_home_slider').find('#videoSlide').length;
              if(videoSlideCount > 0){
                
              }else{
                homeslider.appendSlide(videoSlide, 0);
              }
            }else{
              var videoSlideCount = $('#zxu_home_slider').find('#videoSlide').length;
              if(videoSlideCount > 0){
                homeslider.removeSlide(0);
              }
            }
          }
          setTimeout(function(){
            $('.zxu_top_banner').addClass('zxu_bannerlodedd');
          }, 1000);
          
          
        };

        // trigger function on each page resize
        $(window).on('resize', resize);

        // update size on page load
        
        resize()

        $('#zxu_home_slider').royalSlider('updateSliderSize', true);


        // video play option
        var slider = $("#zxu_home_slider").data('royalSlider'),
            prevSlideVideo,
            playSlideVideo = function() {
              var videoplayButton = $("#zxu_home_slider").find('.playpush');
              if(prevSlideVideo) {
                prevSlideVideo.pause();
                videoplayButton.removeClass('play');
              }
              var video = slider.currSlide.content.find('video');
              if(video.length) {
                prevSlideVideo = video[0];
                prevSlideVideo.play();
                videoplayButton.addClass('play');
                 slider.stopAutoPlay();
              } else {
                prevSlideVideo = null;
                slider.startAutoPlay();
                
              }
              videoplayButton.click(function(){
                if($(this).hasClass('play')){
                  $(this).removeClass('play');
                  prevSlideVideo.pause();
                  slider.startAutoPlay();
                  
                }else{
                   $(this).addClass('play');
                   prevSlideVideo.play();
                   slider.stopAutoPlay();
                }
              })
              
            };
          slider.ev.on('rsAfterSlideChange', playSlideVideo);
          playSlideVideo();

          // mouse move function
          $('#zxu_home_slider').mousemove(function(e){

                var hdopset = 0;
                if($('.header-wrapper').length >0){
                  var headerHeight = $('.header-wrapper').outerHeight();
                  if($('.breadcrumb').length >0){
                    hdopset = headerHeight + $('.breadcrumb').outerHeight();
                  }else{
                    hdopset = headerHeight;
                  }
                }

                var m=getXY(e, this);
                      var   xe = e.pageX - $(window).scrollLeft() - $(this).offset().left;
                        var ye = e.pageY - $(window).scrollTop() - $(this).offset().top + hdopset;
                
                
                var wh = $(window).width();
                var whHalf = wh/2;
                var cursoreHtml = '<div class="sliderAmimatedcursore show"><i class="icon"></i></div>';
                var checkcursoreHave = $('.sliderAmimatedcursore');
                if(m.x <= whHalf){
                  checkcursoreHave.removeClass('right');
                  checkcursoreHave.addClass('left');
                }else{
                  checkcursoreHave.removeClass('left');
                  checkcursoreHave.addClass('right')
                  //console.log('Right');
                }
                checkcursoreHave.css('transform','translate('+xe+'px, '+ye+'px)');

               // console.log(m.x, wh);
          });
          
          $("#zxu_home_slider").mouseleave(function() {
              $('.sliderAmimatedcursore').removeClass('show');
          });

          $("#zxu_home_slider").mouseenter(function() {
              $('.sliderAmimatedcursore').addClass('show');
          });

          $(".zxu_infoBlock--cont .zxu_btn_custom1, .playpush").mouseleave(function() {
              $('.sliderAmimatedcursore').addClass('show');
          });

          $(".zxu_infoBlock--cont .zxu_btn_custom1, .playpush").mouseenter(function() {
              $('.sliderAmimatedcursore').removeClass('show');
          });
      }


        if($("#zxu_galleryHome").length > 0){
          var si = $('#zxu_galleryHome').royalSlider({
              addActiveClass: true,
              arrowsNav: false,
              controlNavigation: 'bullets',
              autoScaleSlider: true, 
              autoScaleSliderWidth: 1384,     
              autoScaleSliderHeight: 480,
              loop: true,
              fadeinLoadedSlide: false,
              globalCaption: true,
              keyboardNavEnabled: false,
              globalCaptionInside: true,
              imageScalePadding:0,
              autoPlay: {
                  enabled: true,
                  pauseOnHover: true,
                  delay:3000
              },
            imgWidth: 1384,
            imgHeight: 939,
              visibleNearby: {
                  enabled: true,
                  centerArea: 0.5,
                  center: true,
                  breakpoint: 767,
                  breakpointCenterArea: 1,
                  navigateByCenterClick: false,
                  autoScaleSliderHeight: 680,
              }
          }).data('royalSlider');
        }


        if($("#zxu_switch_01").length > 0){
            var swich = $("#zxu_switch_01"),
             man = $(".zxu_listItems--man"),
             woman = $(".zxu_listItems--woman");
            swich.val(this.checked);
            if(this.checked) {
                  swich.parents('label.zxu_switch').find('.zxu_slider').addClass('checked');
                   man.show();
                }else{
                  swich.parents('label.zxu_switch').find('.zxu_slider').removeClass('checked');
                    woman.hide();
                }
            swich.change(function() {
                if(this.checked) {
                  swich.parents('label.zxu_switch').find('.zxu_slider').addClass('checked');
                   man.hide();
                   woman.show();
                }else{
                  swich.parents('label.zxu_switch').find('.zxu_slider').removeClass('checked');
                    woman.hide();
                   man.show();
                }
                swich.val(this.checked);        
            });
        }
        

        if( /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)){
            $("#zxu_home_slider").find('.playpush').removeClass('play');
           // playSlideVideo();
        }
        function isElementFixed(el) {
            var $el = $(el);
            while (!$el.is(document)) {
                if ($el.css("position") === "fixed") {
                    return true;
                }
                $el = $el.parent();
            }
            return false;
        }



        function getXY(evt, element) {
                var rect = element.getBoundingClientRect();
                var scrollTop = document.documentElement.scrollTop?
                                document.documentElement.scrollTop:document.body.scrollTop;
                var scrollLeft = document.documentElement.scrollLeft?                   
                                document.documentElement.scrollLeft:document.body.scrollLeft;
                var elementLeft = rect.left+scrollLeft;  
                var elementTop = rect.top+scrollTop;

                x = evt.pageX-elementLeft;
                y = evt.pageY-elementTop;

                return {x:x, y:y};
        }


        function sliderHeightOption(){
          //breadcrumb

                    var sh = $(window).height();
                    var sw = $(window).width();
                    if($('.header-wrapper').left > 0){
                        sh = $(window).height() - $('.header-wrapper').outerHeight();
                    }else{
                       sh = $(window).height();
                    }
                    $("#zxu_home_slider").css({
                        width: sw,
                        height:sh
                    });
                    $('#zxu_home_slider').royalSlider('updateSliderSize', true);
        }

});