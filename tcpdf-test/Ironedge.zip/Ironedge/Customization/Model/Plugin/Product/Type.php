<?php
/**
 * Copyright � 2013-2017 Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

// @codingStandardsIgnoreFile

namespace Ironedge\Customization\Model\Plugin\Product;

use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Framework\Pricing\PriceCurrencyInterface;

/**
 * Bundle Type Model
 * @SuppressWarnings(PHPMD.TooManyFields)
 * @SuppressWarnings(PHPMD.ExcessiveClassComplexity)
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class Type
{
	/**
     * @var Magento\CatalogInventory\Api\StockStateInterface 
     */
    protected $_stockStateInterface;
 
    /**
     * @var Magento\CatalogInventory\Api\StockRegistryInterface 
     */
    protected $_stockRegistry;
 
    /**
    * @param Magento\Framework\App\Helper\Context $context
    * @param Magento\Catalog\Model\Product $product
    * @param Magento\CatalogInventory\Api\StockStateInterface $stockStateInterface,
    * @param Magento\CatalogInventory\Api\StockRegistryInterface $stockRegistry
    */
    public function __construct(
        \Magento\CatalogInventory\Api\StockStateInterface $stockStateInterface,
		\Magento\Catalog\Model\ProductFactory $_productloader,
        \Magento\CatalogInventory\Api\StockRegistryInterface $stockRegistry 
    ) {
        $this->_stockStateInterface = $stockStateInterface;
		$this->_productloader = $_productloader;
        $this->_stockRegistry = $stockRegistry;
    }
	
	public function aroundIsSalable(
            $subject, \Closure $proceed, $product
        ) {
			$_product = $this->_productloader->create()->load($product->getId());
			$collection = $_product->getTypeInstance(true)
            	->getSelectionsCollection($_product->getTypeInstance(true)->getOptionsIds($_product), $_product);
			$salable = true;
			
			foreach($collection as $item)
			{
				if(null !== $item->getData('amasty_native_is_salable'))
				{
					$salable = $item->getData('amasty_native_is_salable');
				}
				if($item->getData('is_salable') == 0 || strpos($item->getData('name'), 'Out of Stock') !== false || !$salable)
				{
					$salable = 0;
					break;
				}
			}
			
			if($salable)
			{
				$stockItem = $this->_stockRegistry->getStockItem($product->getId()); // load stock of that product
				$stockItem->setData('is_in_stock',1);
				$stockItem->setData('qty',0); //set updated quantity 
				$stockItem->setData('manage_stock',1);
				$stockItem->setData('use_config_notify_stock_qty',1);
				$stockItem->save();
			}
			
			return $salable;
		}
}