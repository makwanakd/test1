<?php
namespace Ironedge\ShippingComment\Observer;

use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;

/**
 * Add Delivery information html in order view | Invoice View | Credit memo view | Shipment view
 */
class AddHtmlToOrderShippingView implements ObserverInterface {

    /**
     * @var \Magento\Framework\ObjectManagerInterface
     */
    protected $_objectManager;

    /**
     * @param \Magento\Framework\ObjectManagerInterface $objectmanager
     */
    public function __construct(\Magento\Framework\ObjectManagerInterface $objectmanager) {
        $this->_objectManager = $objectmanager;
    }

    public function execute(EventObserver $observer) {
        if ($observer->getElementName() == 'order_info') {
            $orderShippingViewBlock = $observer->getLayout()->getBlock($observer->getElementName());
            $order = $orderShippingViewBlock->getOrder();

            $deliveryComment = $order->getDeliveryComment();
            
			$deliveryInfoBlock = $this->_objectManager->create('Magento\Framework\View\Element\Template');
            if (!empty($deliveryComment)) {
                $deliveryInfoBlock->setDeliveryComment($deliveryComment);
                $deliveryInfoBlock->setTemplate('Ironedge_ShippingComment::order/view/deliveryinfo.phtml');
                $html = $observer->getTransport()->getOutput() . $deliveryInfoBlock->toHtml();
                $observer->getTransport()->setOutput($html);
            }
        }
    }

}
