<?php
namespace Ironedge\ShippingComment\Observer;

use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;

class PendingReview implements ObserverInterface
{
	/**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $_scopeConfig;
 
    /**
     * Store manager
     *
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;
 
    /**
     * @var \Magento\Framework\Translate\Inline\StateInterface
     */
    protected $inlineTranslation;
 
    /**
     * @var \Magento\Framework\Mail\Template\TransportBuilder
     */
    protected $_transportBuilder;
     
    public function __construct(
		\Magento\Catalog\Model\ProductFactory $_productloader,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Translate\Inline\StateInterface $inlineTranslation,
        \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder
    ) {
		$this->_productloader = $_productloader;
        $this->_storeManager = $storeManager;
        $this->inlineTranslation = $inlineTranslation;
        $this->_transportBuilder = $transportBuilder; 
    }

    /**
     * Set payment fee to order
     * 
     * @param EventObserver $observer
     * @return \Ironedge\ShippingComment\Observer\AddFeeToOrderObserver
     */
    public function execute(\Magento\Framework\Event\Observer $observer) 
	{
		$review = $observer->getDataObject();
		
		$_product = $this->_productloader->create()->load($review->getData('entity_pk_value'));
		//echo $_product->getName();
		//echo "<pre>"; print_r($review->getData()); die;
		/* Receiver Detail  */
		$receiverInfo = [
			'name' => 'Iron Edge',
			//'email' => 'it.himmatjoshi@gmail.com'
			'email' => 'info@ironedge.com.au'
		];
		 
		 
		/* Sender Detail  */
		$senderInfo = [
			'name' => 'Marketing',
			'email' => 'sales@ironedge.com.au',
		];
		
    	$emailTemplateVariables = array();
		$emailTempVariables['product'] = $_product->getName();
		$emailTempVariables['nickname'] = $review['nickname'];
		$emailTempVariables['detail'] = $review['detail'];
		
		$this->sendReviewNotificationMail(
			  $emailTempVariables,
			  $senderInfo,
			  $receiverInfo
		  );
		
    }

	public function sendReviewNotificationMail($emailTemplateVariables,$senderInfo,$receiverInfo)
    {
 
        $this->temp_id = 'review_notification_email_template';
        $this->inlineTranslation->suspend();    
        
		$template =  $this->_transportBuilder->setTemplateIdentifier($this->temp_id)
                ->setTemplateOptions(
                    [
                        'area' => \Magento\Framework\App\Area::AREA_FRONTEND, 
                        'store' => $this->_storeManager->getStore()->getId(),
                    ]
                )
                ->setTemplateVars($emailTemplateVariables)
                ->setFrom($senderInfo)
                ->addTo($receiverInfo['email'],$receiverInfo['name']);  
        $transport = $this->_transportBuilder->getTransport();
        $transport->sendMessage();        
        $this->inlineTranslation->resume();
    }
}
