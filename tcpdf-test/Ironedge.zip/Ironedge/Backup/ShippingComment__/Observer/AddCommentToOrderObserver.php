<?php
namespace Ironedge\ShippingComment\Observer;

use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;

class AddCommentToOrderObserver implements ObserverInterface {

    /**
     * Set payment fee to order
     * 
     * @param EventObserver $observer
     * @return \Ironedge\ShippingComment\Observer\AddFeeToOrderObserver
     */
    public function execute(\Magento\Framework\Event\Observer $observer) {
        $quote = $observer->getQuote();
        $deliveryComment = $quote->getDeliveryComment();
        //Set fee data to order
        try {
			$order = $observer->getOrder();
			$order->setData('delivery_comment', $deliveryComment);
		} catch (\Exception $e) {
			$this->_logger->error($e->getMessage());
		}
        
        return $this;
    }

}
