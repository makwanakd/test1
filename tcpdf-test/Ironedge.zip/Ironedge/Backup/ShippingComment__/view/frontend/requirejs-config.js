var config = {
    map: {
        '*': {
            "Magento_Checkout/js/model/shipping-save-processor/default": "Ironedge_ShippingComment/js/shipping-save-processor-default"
        }
    },
};
