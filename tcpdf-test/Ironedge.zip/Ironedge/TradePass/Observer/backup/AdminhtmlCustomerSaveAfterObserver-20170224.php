<?php

namespace Ironedge\TradePass\Observer;

use Magento\Framework\Event\ObserverInterface;
use Ironedge\TradePass\Model\ResourceModel\TradePass\CollectionFactory;

class AdminhtmlCustomerSaveAfterObserver implements ObserverInterface {

    protected $_objectManager;

    public function __construct(\Magento\Framework\ObjectManagerInterface $objectManager) {
        $this->_objectManager = $objectManager;
    }

    public function execute(\Magento\Framework\Event\Observer $observer) {
        $customer = $observer->getCustomer();
        echo $customerid = $customer->getId();
        die;
        $postData = $observer->getRequest()->getPostValue();
//        print_r($postData);exit;
        if ($postData) {
            $tradePassCollection = $this->_objectManager->create(
                            'Ironedge\TradePass\Model\TradePass'
                    )->getCollection()
                    ->addFieldToFilter(
                    'customer_id', $customerid
            );
            $tradePassId = '';
            foreach ($tradePassCollection as $value)
                $tradePassId = $value->getId();

            $value = $this->_objectManager->create(
                            'Ironedge\TradePass\Model\TradePass'
                    )->load($tradePassId);
            $value->addData($postData);
            $value->setCustomerId($customerid);
            $value->save();
        }
    }

}
