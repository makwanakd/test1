<?php
/**
 *
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Ironedge\OosNotification\Controller\Adminhtml\Trigger;

use Magento\Framework\View\Result\PageFactory;
use Magento\Backend\App\Action\Context;

class Mail extends  \Magento\Backend\App\Action
{
   
    /**
     * @var PageFactory
     */
    protected $resultPageFactory;

	protected $helper;
	
	protected $_resultRedirect;
	
    /**
     * @param Context $context
     * @param Session $customerSession
     * @param PageFactory $resultPageFactory
     * @param Registration $registration
     */
    public function __construct(
        Context $context,
		\Ironedge\OosNotification\Helper\Data $helper,
		\Magento\Framework\Controller\ResultFactory $result,
        PageFactory $resultPageFactory
    ) {
        $this->resultPageFactory = $resultPageFactory;
		$this->_resultRedirect = $result;
		$this->helper = $helper;
        parent::__construct($context);
    }

    /**
     * Customer register form page
     *
     * @return \Magento\Framework\Controller\Result\Redirect|\Magento\Framework\View\Result\Page
     */
    public function execute()
    {
        if($this->helper->sendNotificationEmail())
		{
			$this->messageManager->addSuccess('Notification Sent Successfully!');
		}else{
			$this->messageManager->addError('Issue while sending notification!');
		}
		$resultRedirect = $this->resultRedirectFactory->create();
		$resultRedirect->setUrl($this->_redirect->getRefererUrl());
	
		return $resultRedirect;
    }
}
