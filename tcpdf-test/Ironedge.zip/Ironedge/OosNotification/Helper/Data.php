<?php

namespace Ironedge\OosNotification\Helper;

use Magento\Framework\App\Helper\AbstractHelper;

class Data extends AbstractHelper 
{
    /**
    * Recipient email config path
    */
    const XML_PATH_EMAIL_RECIPIENT = 'contact/email/recipient_email';

    protected $_productCollectionFactory;
	
	protected $_objectManager;

    protected $_transportBuilder;
     
    /**
    * @var \Magento\Framework\Translate\Inline\StateInterface
    */
    protected $inlineTranslation;
     
    /**
    * @var \Magento\Framework\App\Config\ScopeConfigInterface
    */
    protected $scopeConfig;
     
    /**
    * @var \Magento\Store\Model\StoreManagerInterface
    */
    protected $storeManager; 
    /**
    * @var \Magento\Framework\Escaper
    */
    protected $_escaper;
	
	protected $_stockItemRepository;

    /**
    * @param \Magento\Directory\Model\Currency $currency
    * @param \Magento\Framework\App\Request\Http $request
    */
    public function __construct(
        \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder,
		\Magento\Framework\ObjectManagerInterface $objectManager,
        \Magento\Framework\Translate\Inline\StateInterface $inlineTranslation,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Escaper $escaper,
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory,
        \Psr\Log\LoggerInterface $logger,
		\Magento\CatalogInventory\Model\Stock\StockItemRepository $stockItemRepository
    )
    {
		$this->_transportBuilder = $transportBuilder;
		$this->_objectManager = $objectManager;
        $this->inlineTranslation = $inlineTranslation;
        $this->scopeConfig = $scopeConfig;
        $this->storeManager = $storeManager;
        $this->_escaper = $escaper;
        $this->_logger = $logger;
		$this->_stockItemRepository = $stockItemRepository;
        $this->_productCollectionFactory = $productCollectionFactory;
	}
	
	/**
    * send Email to client
    */
    public function sendNotificationEmail() 
    {
		//ini_set('display_errors', 1);
		$productCollectionFactory = $this->_objectManager->create('Magento\Catalog\Model\ResourceModel\Product\CollectionFactory');
		$productCollection = $productCollectionFactory->create()
			->addAttributeToSelect('*')
			->addAttributeToFilter('status',\Magento\Catalog\Model\Product\Attribute\Source\Status::STATUS_ENABLED)
			->addFieldToFilter('type_id', array('in' => array('simple')))
			->addAttributeToSort('created_at', 'DESC')
			//->joinField('stock_item', 'cataloginventory_stock_item', 'qty', 'product_id=entity_id', 'qty=0')
			->load();
		
		
        
        $_baseUrl = $this->storeManager->getStore()->getBaseUrl();
		$store = $this->_objectManager->get('Magento\Store\Model\StoreManagerInterface')->getStore();
		$emailTemplateVariables['products'] = array();
		foreach($productCollection as $product)
        {
			$stockState = $this->_objectManager->get('\Magento\CatalogInventory\Api\StockStateInterface');
			$qty = $stockState->getStockQty($product->getId(), $product->getStore()->getWebsiteId()); 
			if($qty == 0)
			{
				$emailTemplateVariables['products'][$product->getId()]['product_name'] = $product->getName().' (ID : '.$product->getId().')';
				//$emailTemplateVariables['products'][$product->getId()]['url_path'] = $product->getUrl();
				$emailTemplateVariables['products'][$product->getId()]['sku'] = $product->getSku();
				/*$emailTemplateVariables['products'][$product->getId()]['product_image'] = $store->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA) . 'catalog/product' . $product->getImage();*/
			}
			
		}
		//echo "<pre>"; print_r($emailTemplateVariables['products']); die;
		$storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE; 
		$supportName  = $this->scopeConfig->getValue('trans_email/ident_support/name', $storeScope);
		$supportEmail  = $this->scopeConfig->getValue('trans_email/ident_support/email', $storeScope);
		
		$toEmail  = $this->scopeConfig->getValue('ironedge_oosnotification/general/adminemail', $storeScope);
		if(empty($toEmail))
		{
			$toEmail = 'info@ironedge.com.au';
		}
		$this->inlineTranslation->suspend();
		$postObject = new \Magento\Framework\DataObject();
		$postObject->setData($emailTemplateVariables);
		//echo "<pre>"; print_r($postObject->getData()); die;
		$error = false;
		$sender = [
			'name'  => $this->_escaper->escapeHtml($supportName),
			'email' => $this->_escaper->escapeHtml($supportEmail),
		];

		$transport = $this->_transportBuilder
			->setTemplateIdentifier('oos_notification_email') // this code we have mentioned in the email_templates.xml
			->setTemplateOptions(
			[
				'area' => \Magento\Framework\App\Area::AREA_FRONTEND, // this is using frontend area to get the template file
				'store' => \Magento\Store\Model\Store::DEFAULT_STORE_ID,
			]
		)
		->setTemplateVars(['products' => $postObject])
		->setFrom($sender)
		->addTo($toEmail)
		->getTransport();
		
		$transport->sendMessage();
		$this->inlineTranslation->resume();
        $this->_logger->info('OOS Notification Sent successfully - '.date("Y-m-d h:i:sa"));
		
		return true;
    }
}
