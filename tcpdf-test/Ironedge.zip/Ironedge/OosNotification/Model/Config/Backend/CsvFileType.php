<?php

namespace Ironedge\OosNotification\Model\Config\Backend;

class CsvFileType extends \Magento\Config\Model\Config\Backend\File
{
     /**
     * @return string[]
     */
    public function getAllowedExtensions() {
        return ['csv'];
    }
}