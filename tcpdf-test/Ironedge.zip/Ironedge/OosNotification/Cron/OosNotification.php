<?php
  
namespace Ironedge\OosNotification\Cron;
  
class OosNotification
{
	protected $helper;

    /**
    * @param \Magento\Directory\Model\Currency $currency
    * @param \Magento\Framework\App\Request\Http $request
    */
   public function __construct(
        \Ironedge\OosNotification\Helper\Data $helper
    ) {
		$this->helper = $helper;
    }

    /**
    * send Email to client
    */
    public function execute() 
    {
		$this->helper->sendNotificationEmail();
    }
}