<?php
/**
* Ironedge
* Copyright (C) 2016 Ironedge <info@ironedge.com.au>
*
* @category Ironedge
* @package Ironedge_OosNotification
* @copyright Copyright (c) 2016 Mage Delight (http://www.ironedge.com.au/)
* @license http://opensource.org/licenses/gpl-3.0.html GNU General Public License,version 3 (GPL-3.0)
* @author Ironedge <info@ironedge.com.au>
*/

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Ironedge_OosNotification',
    __DIR__
);
